import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Car, Calendar, Clock, CreditCard, QrCode, MapPin, Navigation } from 'lucide-react';
import { format } from 'date-fns';
import toast from 'react-hot-toast';
import QRCode from 'qrcode';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  parkingSpot: {
    id: string;
    name: string;
    location: {
      address: string;
      latitude: number;
      longitude: number;
    };
    pricePerHour: number;
    imageUrl: string;
  } | null;
  selectedDate: string;
  selectedTime: string;
  duration: string;
}

const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  parkingSpot,
  selectedDate,
  selectedTime,
  duration
}) => {
  const [step, setStep] = useState(1);
  const [vehicleType, setVehicleType] = useState<'2W' | '4W'>('4W');
  const [qrCode, setQrCode] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  useEffect(() => {
    if (bookingConfirmed && parkingSpot) {
      generateQRCode();
    }
  }, [bookingConfirmed, parkingSpot]);

  const generateQRCode = async () => {
    if (!parkingSpot) return;
    
    try {
      const bookingData = {
        spotId: parkingSpot.id,
        date: selectedDate,
        time: selectedTime,
        duration,
        vehicleType
      };
      
      const qr = await QRCode.toDataURL(JSON.stringify(bookingData));
      setQrCode(qr);
    } catch (error) {
      console.error('Error generating QR code:', error);
    }
  };

  const calculateTotal = () => {
    if (!parkingSpot) return 0;
    const basePrice = parkingSpot.pricePerHour;
    const hours = parseInt(duration);
    const vehicleMultiplier = vehicleType === '2W' ? 0.7 : 1;
    return basePrice * hours * vehicleMultiplier;
  };

  const handlePayment = async () => {
    setIsProcessing(true);
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      setBookingConfirmed(true);
      setStep(3);
      toast.success('Payment successful!');
    } catch (error) {
      toast.error('Payment failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleNavigation = () => {
    if (!parkingSpot) return;
    
    const { latitude, longitude } = parkingSpot.location;
    const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}`;
    window.open(mapsUrl, '_blank');
  };

  return (
    <AnimatePresence>
      {isOpen && parkingSpot && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-xl shadow-xl w-full max-w-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-2xl font-bold text-gray-900">
                {step === 3 ? 'Booking Confirmed!' : 'Book Parking Spot'}
              </h2>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6">
              {step === 1 && (
                <div className="space-y-6">
                  {/* Parking Details */}
                  <div className="flex gap-4">
                    <img
                      src={parkingSpot.imageUrl}
                      alt={parkingSpot.name}
                      className="w-32 h-32 rounded-lg object-cover"
                    />
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">{parkingSpot.name}</h3>
                      <div className="flex items-center text-gray-500 mt-2">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{parkingSpot.location.address}</span>
                      </div>
                      <div className="mt-4">
                        <span className="text-2xl font-bold text-blue-600">
                          ${parkingSpot.pricePerHour}/hr
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Vehicle Type Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Vehicle Type
                    </label>
                    <div className="grid grid-cols-2 gap-4">
                      <button
                        onClick={() => setVehicleType('2W')}
                        className={`p-4 border rounded-lg flex items-center justify-center gap-2 ${
                          vehicleType === '2W'
                            ? 'border-blue-500 bg-blue-50 text-blue-700'
                            : 'border-gray-200 hover:bg-gray-50'
                        }`}
                      >
                        <Car className="h-5 w-5" />
                        2 Wheeler
                      </button>
                      <button
                        onClick={() => setVehicleType('4W')}
                        className={`p-4 border rounded-lg flex items-center justify-center gap-2 ${
                          vehicleType === '4W'
                            ? 'border-blue-500 bg-blue-50 text-blue-700'
                            : 'border-gray-200 hover:bg-gray-50'
                        }`}
                      >
                        <Car className="h-5 w-5" />
                        4 Wheeler
                      </button>
                    </div>
                  </div>

                  {/* Booking Details */}
                  <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-gray-600">
                        <Calendar className="h-5 w-5 mr-2" />
                        <span>Date</span>
                      </div>
                      <span className="font-medium">{format(new Date(selectedDate), 'PP')}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-gray-600">
                        <Clock className="h-5 w-5 mr-2" />
                        <span>Duration</span>
                      </div>
                      <span className="font-medium">{duration} hours</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-gray-600">
                        <Car className="h-5 w-5 mr-2" />
                        <span>Vehicle Type</span>
                      </div>
                      <span className="font-medium">{vehicleType === '2W' ? '2 Wheeler' : '4 Wheeler'}</span>
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <div className="bg-gray-50 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment Summary</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Base Price</span>
                        <span>${parkingSpot.pricePerHour}/hr</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Duration</span>
                        <span>{duration} hours</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Vehicle Type</span>
                        <span>{vehicleType === '2W' ? '2 Wheeler (30% off)' : '4 Wheeler'}</span>
                      </div>
                      <div className="border-t pt-3 mt-3">
                        <div className="flex justify-between text-lg font-semibold">
                          <span>Total Amount</span>
                          <span>${calculateTotal()}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment Method</h3>
                    <div className="space-y-4">
                      <button
                        onClick={handlePayment}
                        disabled={isProcessing}
                        className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                      >
                        <CreditCard className="h-5 w-5" />
                        {isProcessing ? 'Processing...' : 'Pay Now'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="text-center space-y-6">
                  <div className="flex items-center justify-center">
                    <div className="bg-green-100 rounded-full p-3">
                      <CheckCircle className="h-12 w-12 text-green-600" />
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">Booking Confirmed!</h3>
                    <p className="text-gray-600 mt-2">Your parking spot has been reserved</p>
                  </div>

                  {qrCode && (
                    <div className="flex justify-center">
                      <img src={qrCode} alt="Booking QR Code" className="w-48 h-48" />
                    </div>
                  )}

                  <div className="flex flex-col gap-3">
                    <button
                      onClick={handleNavigation}
                      className="flex items-center justify-center gap-2 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700"
                    >
                      <Navigation className="h-5 w-5" />
                      Navigate to Parking
                    </button>
                    <button
                      onClick={onClose}
                      className="text-gray-600 hover:text-gray-800"
                    >
                      Return to Search
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            {step < 3 && (
              <div className="border-t p-6 bg-gray-50">
                <div className="flex justify-between">
                  {step > 1 ? (
                    <button
                      onClick={() => setStep(step - 1)}
                      className="text-gray-600 hover:text-gray-800"
                    >
                      Back
                    </button>
                  ) : (
                    <div />
                  )}
                  {step === 1 && (
                    <button
                      onClick={() => setStep(2)}
                      className="flex items-center gap-2 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
                    >
                      Continue to Payment
                      <CreditCard className="h-5 w-5" />
                    </button>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default BookingModal;