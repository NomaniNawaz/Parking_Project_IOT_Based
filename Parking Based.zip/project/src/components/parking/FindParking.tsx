import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, MapPin, Calendar, Clock, Filter, Car, Star, DollarSign, ArrowLeft } from 'lucide-react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { useNavigate } from 'react-router-dom';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { supabase } from '../../lib/supabase';
import BookingModal from './BookingModal';
import toast from 'react-hot-toast';

interface ParkingSpot {
  id: string;
  name: string;
  location: {
    address: string;
    latitude: number;
    longitude: number;
  };
  pricePerHour: number;
  availableSpots: number;
  totalSpots: number;
  rating: number;
  imageUrl: string;
  features: string[];
}

const cityImages = [
  {
    city: "New York",
    image: "https://images.unsplash.com/photo-1522083165195-3424ed129620",
    spots: 245
  },
  {
    city: "San Francisco",
    image: "https://images.unsplash.com/photo-1501594907352-04cda38ebc29",
    spots: 189
  },
  {
    city: "Chicago",
    image: "https://images.unsplash.com/photo-1494522855154-9297ac14b55f",
    spots: 167
  },
  {
    city: "Boston",
    image: "https://images.unsplash.com/photo-1501979376754-1d09c1c2610c",
    spots: 134
  }
];

const FindParking: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedTime, setSelectedTime] = useState('10:00');
  const [duration, setDuration] = useState('2');
  const [parkingSpots, setParkingSpots] = useState<ParkingSpot[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    priceRange: [0, 100],
    type: 'all',
    features: [] as string[]
  });
  const [selectedSpot, setSelectedSpot] = useState<ParkingSpot | null>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);

  useEffect(() => {
    fetchParkingSpots();
  }, []);

  const fetchParkingSpots = async () => {
    try {
      const { data, error } = await supabase
        .from('parking_spaces')
        .select('*')
        .eq('status', 'active');

      if (error) throw error;

      setParkingSpots(data || []);
    } catch (error) {
      console.error('Error fetching parking spots:', error);
      toast.error('Failed to load parking spots');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    if (!searchQuery) {
      toast.error('Please enter a location');
      return;
    }
    toast.success(`Searching for parking spots near ${searchQuery}`);
  };

  const handleBooking = (spot: ParkingSpot) => {
    setSelectedSpot(spot);
    setShowBookingModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Back Button */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Dashboard
          </button>
        </div>
      </div>

      {/* Hero Section with City Slideshow */}
      <div className="relative h-[50vh] overflow-hidden">
        <Swiper
          spaceBetween={0}
          slidesPerView={1}
          autoplay={{ delay: 5000 }}
          loop={true}
          className="h-full"
        >
          {cityImages.map((city, index) => (
            <SwiperSlide key={index}>
              <div className="relative h-full">
                <img
                  src={city.image}
                  alt={city.city}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                  <div className="text-center text-white">
                    <h2 className="text-4xl font-bold mb-2">{city.city}</h2>
                    <p className="text-xl">{city.spots} parking spots available</p>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>

      {/* Search Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-10">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Enter location..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="relative">
              <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <select
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="1">1 hour</option>
                <option value="2">2 hours</option>
                <option value="4">4 hours</option>
                <option value="8">8 hours</option>
                <option value="24">24 hours</option>
              </select>
            </div>
            <button
              onClick={handleSearch}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              <Car className="h-5 w-5" />
              Find Parking
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters */}
          <div className="w-full md:w-64 space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Filters</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Price Range (per hour)
                  </label>
                  <div className="flex items-center gap-4">
                    <DollarSign className="h-5 w-5 text-gray-400" />
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={filters.priceRange[1]}
                      onChange={(e) => setFilters({
                        ...filters,
                        priceRange: [0, parseInt(e.target.value)]
                      })}
                      className="w-full"
                    />
                    <span className="text-sm text-gray-600">${filters.priceRange[1]}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Parking Type
                  </label>
                  <select
                    value={filters.type}
                    onChange={(e) => setFilters({ ...filters, type: e.target.value })}
                    className="w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="all">All Types</option>
                    <option value="covered">Covered</option>
                    <option value="open">Open</option>
                    <option value="valet">Valet</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Features
                  </label>
                  <div className="space-y-2">
                    {['24/7 Security', 'EV Charging', 'CCTV', 'Car Wash'].map((feature) => (
                      <label key={feature} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={filters.features.includes(feature)}
                          onChange={(e) => {
                            const newFeatures = e.target.checked
                              ? [...filters.features, feature]
                              : filters.features.filter(f => f !== feature);
                            setFilters({ ...filters, features: newFeatures });
                          }}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-2 text-sm text-gray-600">{feature}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Parking Spots Grid */}
          <div className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loading ? (
                Array(6).fill(0).map((_, i) => (
                  <div key={i} className="animate-pulse bg-white rounded-lg shadow-sm p-4 h-64" />
                ))
              ) : parkingSpots.length > 0 ? (
                parkingSpots.map((spot) => (
                  <motion.div
                    key={spot.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
                  >
                    <img
                      src={spot.imageUrl || "https://images.unsplash.com/photo-1470224114660-3f6686c562eb"}
                      alt={spot.name}
                      className="w-full h-40 object-cover"
                    />
                    <div className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{spot.name}</h3>
                          <div className="mt-1 flex items-center text-sm text-gray-500">
                            <MapPin className="h-4 w-4 mr-1" />
                            <span>{spot.location.address}</span>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-400" />
                          <span className="ml-1 text-sm font-medium text-gray-600">{spot.rating}</span>
                        </div>
                      </div>

                      <div className="mt-4 flex items-center justify-between">
                        <div className="text-lg font-bold text-blue-600">
                          ${spot.pricePerHour}/hr
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          spot.availableSpots > 10
                            ? 'bg-green-100 text-green-800'
                            : spot.availableSpots > 0
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {spot.availableSpots} spots left
                        </span>
                      </div>

                      <button
                        onClick={() => handleBooking(spot)}
                        className="mt-4 w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                      >
                        <Car className="h-5 w-5" />
                        Book Now
                      </button>
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <Car className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">No parking spots found</h3>
                  <p className="mt-2 text-gray-500">Try adjusting your search criteria</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Add Booking Modal */}
      <BookingModal
        isOpen={showBookingModal}
        onClose={() => setShowBookingModal(false)}
        parkingSpot={selectedSpot}
        selectedDate={selectedDate}
        selectedTime={selectedTime}
        duration={duration}
      />
    </div>
  );
};

export default FindParking;