import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, Car, DollarSign, Search, Shield, Zap, Sparkles } from 'lucide-react';
import { getParkingSpaces } from '../../lib/parking';
import { ParkingSpace } from '../../types/parking';
import toast from 'react-hot-toast';

interface ParkingSpaceListProps {
  onSelect?: (space: ParkingSpace) => void;
}

const ParkingSpaceList: React.FC<ParkingSpaceListProps> = ({ onSelect }) => {
  const [spaces, setSpaces] = useState<ParkingSpace[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: '',
    minPrice: '',
    maxPrice: '',
    sortBy: 'price',
    features: [] as string[]
  });

  useEffect(() => {
    const loadSpaces = async () => {
      try {
        const data = await getParkingSpaces({
          minPrice: filters.minPrice ? parseFloat(filters.minPrice) : undefined,
          maxPrice: filters.maxPrice ? parseFloat(filters.maxPrice) : undefined
        });
        setSpaces(data);
      } catch (error) {
        toast.error('Failed to load parking spaces');
      } finally {
        setLoading(false);
      }
    };

    loadSpaces();
  }, [filters.minPrice, filters.maxPrice]);

  const getFeatureIcon = (feature: string) => {
    switch (feature.toLowerCase()) {
      case '24/7 security':
      case 'security guards':
        return Shield;
      case 'ev charging':
        return Zap;
      default:
        return Sparkles;
    }
  };

  const filteredSpaces = spaces.filter(space => {
    const matchesSearch = space.name.toLowerCase().includes(filters.search.toLowerCase()) ||
      space.location.address.toLowerCase().includes(filters.search.toLowerCase());
    
    const matchesFeatures = filters.features.length === 0 ||
      filters.features.every(feature => 
        space.features.some(f => f.toLowerCase().includes(feature.toLowerCase()))
      );

    return matchesSearch && matchesFeatures;
  });

  const sortedSpaces = [...filteredSpaces].sort((a, b) => {
    switch (filters.sortBy) {
      case 'price':
        return a.pricePerHour - b.pricePerHour;
      case 'availability':
        return b.availableSpots - a.availableSpots;
      case 'name':
        return a.name.localeCompare(b.name);
      default:
        return 0;
    }
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              placeholder="Search by name or location..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Min Price ($/hr)
              </label>
              <input
                type="number"
                value={filters.minPrice}
                onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })}
                placeholder="Min price"
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Max Price ($/hr)
              </label>
              <input
                type="number"
                value={filters.maxPrice}
                onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
                placeholder="Max price"
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Sort By
              </label>
              <select
                value={filters.sortBy}
                onChange={(e) => setFilters({ ...filters, sortBy: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="price">Price (Low to High)</option>
                <option value="availability">Availability</option>
                <option value="name">Name (A-Z)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Features
            </label>
            <div className="flex flex-wrap gap-2">
              {['24/7 Security', 'EV Charging', 'Valet Service', 'Covered Parking'].map((feature) => (
                <button
                  key={feature}
                  onClick={() => {
                    const newFeatures = filters.features.includes(feature)
                      ? filters.features.filter(f => f !== feature)
                      : [...filters.features, feature];
                    setFilters({ ...filters, features: newFeatures });
                  }}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                    filters.features.includes(feature)
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {feature}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Parking Spaces List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedSpaces.map((space) => (
          <motion.div
            key={space.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: 1.02 }}
            className="bg-white rounded-lg shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => onSelect?.(space)}
          >
            <div className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{space.name}</h3>
                  <div className="mt-2 flex items-center text-sm text-gray-500">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{space.location.address}</span>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  space.availableSpots > 10
                    ? 'bg-green-100 text-green-800'
                    : space.availableSpots > 0
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {space.availableSpots} spots
                </span>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-4">
                <div className="flex items-center">
                  <DollarSign className="h-5 w-5 text-gray-400" />
                  <span className="ml-2 text-gray-900">${space.pricePerHour}/hr</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-gray-400" />
                  <span className="ml-2 text-gray-900">24/7</span>
                </div>
              </div>

              <div className="mt-4">
                <div className="flex flex-wrap gap-2">
                  {space.features.slice(0, 3).map((feature, index) => {
                    const Icon = getFeatureIcon(feature);
                    return (
                      <span
                        key={index}
                        className="px-2 py-1 bg-blue-50 text-blue-700 rounded-full text-xs flex items-center gap-1"
                      >
                        <Icon className="h-3 w-3" />
                        {feature}
                      </span>
                    );
                  })}
                  {space.features.length > 3 && (
                    <span className="px-2 py-1 bg-gray-50 text-gray-600 rounded-full text-xs">
                      +{space.features.length - 3} more
                    </span>
                  )}
                </div>
              </div>

              <button
                className="mt-6 w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelect?.(space);
                }}
              >
                <Car className="h-5 w-5" />
                <span>Book Now</span>
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {sortedSpaces.length === 0 && (
        <div className="text-center py-12">
          <Car className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900">No parking spaces found</h3>
          <p className="mt-2 text-gray-500">Try adjusting your filters</p>
        </div>
      )}
    </div>
  );
};

export default ParkingSpaceList;