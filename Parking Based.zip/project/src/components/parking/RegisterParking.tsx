import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import { Upload, MapPin, DollarSign, Calendar, FileText, Camera, Ban as Bank, Shield, CheckCircle, AlertTriangle, Building, Phone } from 'lucide-react';
import toast from 'react-hot-toast';
import { supabase } from '../../lib/supabase';

interface DocumentStatus {
  propertyProof: boolean;
  idProof: boolean;
  bankDetails: boolean;
  noc: boolean;
}

const RegisterParking = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    price: '',
    spaces: '',
    amenities: [] as string[],
    description: '',
    ownerName: '',
    phone: '',
    email: '',
    bankAccount: '',
    ifsc: '',
    upiId: '',
    coordinates: { lat: '', lng: '' }
  });

  const [documents, setDocuments] = useState<Record<string, File[]>>({
    propertyProof: [],
    idProof: [],
    bankDetails: [],
    noc: [],
    photos: []
  });

  const [verificationStatus, setVerificationStatus] = useState<DocumentStatus>({
    propertyProof: false,
    idProof: false,
    bankDetails: false,
    noc: false
  });

  const onDrop = useCallback((acceptedFiles: File[], type: string) => {
    setDocuments(prev => ({
      ...prev,
      [type]: [...prev[type], ...acceptedFiles]
    }));
    toast.success(`${acceptedFiles.length} files uploaded for ${type}`);
  }, []);

  const { getRootProps: getPropertyRootProps, getInputProps: getPropertyInputProps } = useDropzone({
    onDrop: files => onDrop(files, 'propertyProof'),
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.jpeg', '.jpg', '.png']
    }
  });

  const { getRootProps: getIdRootProps, getInputProps: getIdInputProps } = useDropzone({
    onDrop: files => onDrop(files, 'idProof'),
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.jpeg', '.jpg', '.png']
    }
  });

  const { getRootProps: getBankRootProps, getInputProps: getBankInputProps } = useDropzone({
    onDrop: files => onDrop(files, 'bankDetails'),
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.jpeg', '.jpg', '.png']
    }
  });

  const { getRootProps: getNocRootProps, getInputProps: getNocInputProps } = useDropzone({
    onDrop: files => onDrop(files, 'noc'),
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.jpeg', '.jpg', '.png']
    }
  });

  const { getRootProps: getPhotoRootProps, getInputProps: getPhotoInputProps } = useDropzone({
    onDrop: files => onDrop(files, 'photos'),
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png']
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (step < 4) {
      setStep(step + 1);
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Please sign in to register your parking space');

      // Upload documents to storage
      const uploadPromises = Object.entries(documents).map(async ([type, files]) => {
        const uploads = files.map(async (file) => {
          const fileName = `${user.id}/${type}/${file.name}`;
          const { error } = await supabase.storage
            .from('parking-documents')
            .upload(fileName, file);
          
          if (error) throw error;
          return fileName;
        });
        return Promise.all(uploads);
      });

      await Promise.all(uploadPromises);

      // Create parking space
      const { error: parkingError } = await supabase
        .from('parking_spaces')
        .insert([
          {
            owner_id: user.id,
            name: formData.name,
            location: {
              address: formData.address,
              latitude: parseFloat(formData.coordinates.lat),
              longitude: parseFloat(formData.coordinates.lng)
            },
            total_slots: parseInt(formData.spaces),
            price_per_hour: parseFloat(formData.price),
            amenities: formData.amenities,
            status: 'pending',
            photos: documents.photos.map(f => f.name),
            documents: {
              propertyProof: documents.propertyProof.map(f => f.name),
              idProof: documents.idProof.map(f => f.name),
              bankDetails: documents.bankDetails.map(f => f.name),
              noc: documents.noc.map(f => f.name)
            }
          }
        ]);

      if (parkingError) throw parkingError;

      toast.success('Registration submitted successfully! Our team will review your documents.');
    } catch (error: any) {
      console.error('Registration error:', error);
      toast.error(error.message || 'Failed to submit registration');
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-900">Basic Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Owner Name</label>
                <input
                  type="text"
                  value={formData.ownerName}
                  onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Phone Number</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-900">Property Details</h2>
            <div>
              <label className="block text-sm font-medium text-gray-700">Property Documents</label>
              <div {...getPropertyRootProps()} className="mt-1 border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-blue-500">
                <input {...getPropertyInputProps()} />
                <FileText className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-600">
                  Upload property proof (Sale Deed, Lease Agreement, etc.)
                </p>
              </div>
              {documents.propertyProof.length > 0 && (
                <div className="mt-2">
                  <p className="text-sm text-green-600">
                    {documents.propertyProof.length} documents uploaded
                  </p>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">NOC (No Objection Certificate)</label>
              <div {...getNocRootProps()} className="mt-1 border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-blue-500">
                <input {...getNocInputProps()} />
                <Building className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-600">
                  Upload Municipal Corporation NOC
                </p>
              </div>
              {documents.noc.length > 0 && (
                <div className="mt-2">
                  <p className="text-sm text-green-600">
                    {documents.noc.length} documents uploaded
                  </p>
                </div>
              )}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-900">Identity Verification</h2>
            <div>
              <label className="block text-sm font-medium text-gray-700">ID Proof</label>
              <div {...getIdRootProps()} className="mt-1 border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-blue-500">
                <input {...getIdInputProps()} />
                <Shield className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-600">
                  Upload ID proof (Aadhaar, Passport, Driver's License)
                </p>
              </div>
              {documents.idProof.length > 0 && (
                <div className="mt-2">
                  <p className="text-sm text-green-600">
                    {documents.idProof.length} documents uploaded
                  </p>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Parking Space Photos</label>
              <div {...getPhotoRootProps()} className="mt-1 border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-blue-500">
                <input {...getPhotoInputProps()} />
                <Camera className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-600">
                  Upload photos of your parking space
                </p>
              </div>
              {documents.photos.length > 0 && (
                <div className="mt-2">
                  <p className="text-sm text-green-600">
                    {documents.photos.length} photos uploaded
                  </p>
                </div>
              )}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-900">Bank Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Bank Account Number</label>
                <input
                  type="text"
                  value={formData.bankAccount}
                  onChange={(e) => setFormData({ ...formData, bankAccount: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">IFSC Code</label>
                <input
                  type="text"
                  value={formData.ifsc}
                  onChange={(e) => setFormData({ ...formData, ifsc: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">UPI ID (Optional)</label>
                <input
                  type="text"
                  value={formData.upiId}
                  onChange={(e) => setFormData({ ...formData, upiId: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Bank Documents</label>
              <div {...getBankRootProps()} className="mt-1 border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-blue-500">
                <input {...getBankInputProps()} />
                <Bank className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-600">
                  Upload cancelled cheque or bank statement
                </p>
              </div>
              {documents.bankDetails.length > 0 && (
                <div className="mt-2">
                  <p className="text-sm text-green-600">
                    {documents.bankDetails.length} documents uploaded
                  </p>
                </div>
              )}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-gray-50 py-12"
    >
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="px-8 py-6 border-b">
            <h1 className="text-2xl font-bold text-gray-900">Register Your Parking Space</h1>
            <p className="mt-2 text-sm text-gray-600">
              Complete the registration process by providing required information and documents
            </p>
          </div>

          {/* Progress Steps */}
          <div className="px-8 py-4 bg-gray-50 border-b">
            <div className="flex justify-between">
              {[1, 2, 3, 4].map((s) => (
                <div
                  key={s}
                  className={`flex items-center ${s < step ? 'text-green-600' : s === step ? 'text-blue-600' : 'text-gray-400'}`}
                >
                  <div className={`flex items-center justify-center h-8 w-8 rounded-full ${
                    s < step ? 'bg-green-100' : s === step ? 'bg-blue-100' : 'bg-gray-100'
                  }`}>
                    {s < step ? (
                      <CheckCircle className="h-5 w-5" />
                    ) : (
                      <span className="text-sm font-medium">{s}</span>
                    )}
                  </div>
                  <span className="ml-2 text-sm font-medium">
                    {s === 1 ? 'Basic Info' : s === 2 ? 'Property' : s === 3 ? 'Identity' : 'Bank Details'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmit} className="px-8 py-6">
            {renderStep()}

            <div className="mt-6 flex justify-between">
              {step > 1 && (
                <button
                  type="button"
                  onClick={() => setStep(step - 1)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Previous
                </button>
              )}
              <button
                type="submit"
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 ml-auto"
              >
                {step === 4 ? 'Submit Registration' : 'Next'}
              </button>
            </div>
          </form>
        </div>

        {/* Help Section */}
        <div className="mt-8 bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="h-5 w-5 text-yellow-500" />
            <h2 className="text-lg font-semibold text-gray-900">Important Information</h2>
          </div>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              All documents should be clear and legible
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Property documents must be officially verified
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Bank details must match with the property owner's name
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Verification process typically takes 2-3 business days
            </li>
          </ul>
        </div>
      </div>
    </motion.div>
  );
};

export default RegisterParking;