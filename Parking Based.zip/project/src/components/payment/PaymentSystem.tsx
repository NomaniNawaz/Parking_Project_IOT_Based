import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { motion } from 'framer-motion';
import { CreditCard, Wallet, Ban as Bank, Bitcoin, Shield, AlertTriangle, CheckCircle, History, Save } from 'lucide-react';
import toast from 'react-hot-toast';

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface PaymentMethod {
  id: string;
  type: 'card' | 'wallet' | 'bank' | 'crypto';
  label: string;
  icon: React.ElementType;
  processor: string;
}

const paymentMethods: PaymentMethod[] = [
  { id: 'card', type: 'card', label: 'Credit/Debit Card', icon: CreditCard, processor: 'stripe' },
  { id: 'wallet', type: 'wallet', label: 'Digital Wallet', icon: Wallet, processor: 'stripe' },
  { id: 'bank', type: 'bank', label: 'Bank Transfer', icon: Bank, processor: 'stripe' },
  { id: 'crypto', type: 'crypto', label: 'Cryptocurrency', icon: Bitcoin, processor: 'crypto' }
];

interface PaymentSystemProps {
  amount: number;
  currency?: string;
  onSuccess?: (paymentId: string) => void;
  onError?: (error: Error) => void;
}

const PaymentSystem: React.FC<PaymentSystemProps> = ({
  amount,
  currency = 'USD',
  onSuccess,
  onError
}) => {
  const [selectedMethod, setSelectedMethod] = useState<string>('card');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [saveCard, setSaveCard] = useState(false);
  const [requires2FA, setRequires2FA] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');

  useEffect(() => {
    // Initialize payment processors
    const initializePayments = async () => {
      try {
        const stripe = await stripePromise;
        if (!stripe) {
          throw new Error('Failed to initialize Stripe');
        }
      } catch (err) {
        setError('Payment system initialization failed');
        onError?.(err as Error);
      }
    };

    initializePayments();
  }, [onError]);

  const validateCard = (): boolean => {
    if (cardNumber.length < 16) {
      setError('Invalid card number');
      return false;
    }
    if (expiryDate.length < 5) {
      setError('Invalid expiry date');
      return false;
    }
    if (cvv.length < 3) {
      setError('Invalid CVV');
      return false;
    }
    return true;
  };

  const handlePayment = async () => {
    try {
      setLoading(true);
      setError(null);

      // Validate form
      if (!validateCard()) {
        return;
      }

      // Simulate 2FA check
      if (!requires2FA && Math.random() > 0.7) {
        setRequires2FA(true);
        return;
      }

      if (requires2FA && !verificationCode) {
        setError('2FA verification code required');
        return;
      }

      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Simulate success/failure
      if (Math.random() > 0.1) {
        const paymentId = `pay_${Math.random().toString(36).substr(2, 9)}`;
        toast.success('Payment processed successfully');
        onSuccess?.(paymentId);

        // Save card if requested
        if (saveCard) {
          toast.success('Payment method saved for future use');
        }
      } else {
        throw new Error('Payment failed. Please try again.');
      }
    } catch (err) {
      const error = err as Error;
      setError(error.message);
      onError?.(error);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">Secure Payment</h2>
          <Shield className="h-6 w-6 text-green-600" />
        </div>

        {/* Amount Display */}
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Amount:</span>
            <span className="text-xl font-bold text-gray-900">
              {new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: currency
              }).format(amount)}
            </span>
          </div>
        </div>

        {/* Payment Method Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Payment Method
          </label>
          <div className="grid grid-cols-2 gap-4">
            {paymentMethods.map((method) => (
              <button
                key={method.id}
                onClick={() => setSelectedMethod(method.id)}
                className={`flex items-center gap-2 p-3 rounded-lg border transition-colors ${
                  selectedMethod === method.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <method.icon className={`h-5 w-5 ${
                  selectedMethod === method.id ? 'text-blue-500' : 'text-gray-400'
                }`} />
                <span className={`text-sm ${
                  selectedMethod === method.id ? 'text-blue-700' : 'text-gray-600'
                }`}>
                  {method.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Card Details Form */}
        {selectedMethod === 'card' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Card Number
              </label>
              <input
                type="text"
                maxLength={16}
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, ''))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                placeholder="1234 5678 9012 3456"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Expiry Date
                </label>
                <input
                  type="text"
                  maxLength={5}
                  value={expiryDate}
                  onChange={(e) => {
                    let value = e.target.value.replace(/\D/g, '');
                    if (value.length >= 2) {
                      value = value.slice(0, 2) + '/' + value.slice(2);
                    }
                    setExpiryDate(value);
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  placeholder="MM/YY"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  CVV
                </label>
                <input
                  type="text"
                  maxLength={4}
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  placeholder="123"
                />
              </div>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="save-card"
                checked={saveCard}
                onChange={(e) => setSaveCard(e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="save-card" className="ml-2 text-sm text-gray-600">
                Save card for future payments
              </label>
            </div>
          </motion.div>
        )}

        {/* 2FA Verification */}
        {requires2FA && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4"
          >
            <label className="block text-sm font-medium text-gray-700 mb-1">
              2FA Verification Code
            </label>
            <input
              type="text"
              maxLength={6}
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter verification code"
            />
          </motion.div>
        )}

        {/* Error Display */}
        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md"
          >
            <div className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="h-5 w-5" />
              <span className="text-sm">{error}</span>
            </div>
          </motion.div>
        )}

        {/* Action Buttons */}
        <div className="mt-6 space-y-3">
          <button
            onClick={handlePayment}
            disabled={loading}
            className={`w-full flex items-center justify-center gap-2 px-4 py-2 border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
              loading ? 'opacity-75 cursor-not-allowed' : ''
            }`}
          >
            {loading ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                >
                  <Shield className="h-5 w-5" />
                </motion.div>
                <span>Processing...</span>
              </>
            ) : (
              <>
                <CheckCircle className="h-5 w-5" />
                <span>Pay Now</span>
              </>
            )}
          </button>

          <button
            onClick={() => {/* Implement view history */}}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <History className="h-5 w-5" />
            <span>View Payment History</span>
          </button>
        </div>

        {/* Security Badges */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center justify-center gap-4 text-gray-400">
            <Shield className="h-6 w-6" />
            <span className="text-xs">PCI DSS Compliant</span>
            <span>•</span>
            <span className="text-xs">256-bit SSL Encryption</span>
            <span>•</span>
            <span className="text-xs">Secure Checkout</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentSystem;