import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Users, Car, BarChart, Settings, Calendar, PenTool as Tool, Activity, Bell, Search, AlertTriangle, MapPin, Home, LogOut } from 'lucide-react';
import UserManagement from './sections/UserManagement';
import ContentManagement from './sections/ContentManagement';
import ServiceProviders from './sections/ServiceProviders';
import BookingManagement from './sections/BookingManagement';
import EmergencyServices from './sections/EmergencyServices';
import Analytics from './sections/Analytics';
import SystemSettings from './sections/SystemSettings';
import Notifications from './sections/Notifications';
import LandRegistration from './sections/LandRegistration';
import { supabase } from '../../lib/supabase';
import { getNotifications } from '../../lib/notifications';
import toast from 'react-hot-toast';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('analytics');
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dashboardStats, setDashboardStats] = useState({
    totalUsers: 0,
    activeBookings: 0,
    serviceProviders: 0,
    emergencyRequests: 0
  });

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Fetch notifications
      const notifs = await getNotifications();
      setNotifications(notifs);

      // Fetch statistics
      const [
        { count: usersCount },
        { count: bookingsCount },
        { count: providersCount },
        { count: emergencyCount }
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact' }),
        supabase.from('bookings').select('*', { count: 'exact' }).eq('status', 'active'),
        supabase.from('service_providers').select('*', { count: 'exact' }),
        supabase.from('emergency_requests').select('*', { count: 'exact' }).eq('status', 'pending')
      ]);

      setDashboardStats({
        totalUsers: usersCount || 0,
        activeBookings: bookingsCount || 0,
        serviceProviders: providersCount || 0,
        emergencyRequests: emergencyCount || 0
      });

    } catch (err) {
      console.error('Error fetching dashboard data:', err);
      setError('Failed to load dashboard data');
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      localStorage.removeItem('isAdmin');
      navigate('/');
      toast.success('Signed out successfully');
    } catch (error) {
      console.error('Error signing out:', error);
      toast.error('Failed to sign out');
    }
  };

  const handleGoHome = () => {
    navigate('/');
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-gray-50"
    >
      {/* Top Navigation Bar */}
      <div className="bg-white shadow-sm py-4 px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Car className="h-8 w-8 text-blue-600" />
          <span className="text-xl font-bold">Admin Dashboard</span>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={handleGoHome}
            className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Home className="h-5 w-5" />
            <span>Home</span>
          </button>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
          >
            <LogOut className="h-5 w-5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white h-screen shadow-lg fixed">
          <div className="p-6">
            <nav className="space-y-2">
              {[
                { name: 'Analytics', icon: BarChart, id: 'analytics' },
                { name: 'User Management', icon: Users, id: 'users' },
                { name: 'Content Management', icon: Settings, id: 'content' },
                { name: 'Service Providers', icon: Tool, id: 'providers' },
                { name: 'Bookings', icon: Calendar, id: 'bookings' },
                { name: 'Emergency Services', icon: Activity, id: 'emergency' },
                { name: 'Land Registration', icon: MapPin, id: 'land-registration' },
                { name: 'System Settings', icon: Settings, id: 'settings' },
                { name: 'Notifications', icon: Bell, id: 'notifications', badge: notifications.length },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`w-full flex items-center justify-between gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeSection === item.id
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <item.icon className="h-5 w-5" />
                    <span className="text-sm font-medium">{item.name}</span>
                  </div>
                  {item.badge && (
                    <span className="bg-red-100 text-red-600 px-2 py-1 rounded-full text-xs font-semibold">
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 ml-64 p-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[
              { label: 'Total Users', value: dashboardStats.totalUsers.toString(), icon: Users, color: 'bg-blue-100 text-blue-600' },
              { label: 'Active Bookings', value: dashboardStats.activeBookings.toString(), icon: Calendar, color: 'bg-green-100 text-green-600' },
              { label: 'Service Providers', value: dashboardStats.serviceProviders.toString(), icon: Tool, color: 'bg-purple-100 text-purple-600' },
              { label: 'Emergency Requests', value: dashboardStats.emergencyRequests.toString(), icon: Activity, color: 'bg-red-100 text-red-600' },
            ].map((stat) => (
              <div key={stat.label} className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-full ${stat.color}`}>
                    <stat.icon className="h-6 w-6" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Dynamic Section Content */}
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
            </div>
          ) : error ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <p className="text-red-600">{error}</p>
                <button
                  onClick={() => window.location.reload()}
                  className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Retry
                </button>
              </div>
            </div>
          ) : (
            <>
              {activeSection === 'users' && <UserManagement />}
              {activeSection === 'content' && <ContentManagement />}
              {activeSection === 'providers' && <ServiceProviders />}
              {activeSection === 'bookings' && <BookingManagement />}
              {activeSection === 'emergency' && <EmergencyServices />}
              {activeSection === 'analytics' && <Analytics />}
              {activeSection === 'settings' && <SystemSettings />}
              {activeSection === 'notifications' && <Notifications />}
              {activeSection === 'land-registration' && <LandRegistration />}
            </>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default AdminDashboard;