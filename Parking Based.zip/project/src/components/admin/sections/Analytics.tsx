import React from 'react';
import { BarChart, LineChart, PieChart, TrendingUp, Users, Star } from 'lucide-react';

const Analytics = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h2>
        <div className="flex items-center gap-4">
          <select className="px-4 py-2 border rounded-lg">
            <option>Last 7 days</option>
            <option>Last 30 days</option>
            <option>Last 3 months</option>
            <option>Last year</option>
          </select>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Download Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Revenue Overview</h3>
            <TrendingUp className="h-5 w-5 text-green-500" />
          </div>
          <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-lg">
            <BarChart className="h-8 w-8 text-gray-400" />
            <span className="ml-2 text-gray-500">Revenue Chart Placeholder</span>
          </div>
        </div>

        {/* Booking Statistics */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Booking Statistics</h3>
            <LineChart className="h-5 w-5 text-blue-500" />
          </div>
          <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-lg">
            <LineChart className="h-8 w-8 text-gray-400" />
            <span className="ml-2 text-gray-500">Bookings Chart Placeholder</span>
          </div>
        </div>

        {/* User Demographics */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">User Demographics</h3>
            <Users className="h-5 w-5 text-purple-500" />
          </div>
          <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-lg">
            <PieChart className="h-8 w-8 text-gray-400" />
            <span className="ml-2 text-gray-500">Demographics Chart Placeholder</span>
          </div>
        </div>

        {/* Customer Satisfaction */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Customer Satisfaction</h3>
            <Star className="h-5 w-5 text-yellow-500" />
          </div>
          <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-lg">
            <BarChart className="h-8 w-8 text-gray-400" />
            <span className="ml-2 text-gray-500">Satisfaction Chart Placeholder</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;