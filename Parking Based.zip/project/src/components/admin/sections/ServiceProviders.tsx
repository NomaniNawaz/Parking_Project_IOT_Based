import React, { useState, useEffect } from 'react';
import { Search, PenTool as Tool, Clock, MapPin, Star, Phone, Shield, AlertTriangle, CheckCircle, X, Trash2, Edit2 } from 'lucide-react';
import toast from 'react-hot-toast';

const ServiceProviders = () => {
  const [providers, setProviders] = useState([
    {
      id: 1,
      name: 'John Smith',
      type: 'Mechanic',
      specialization: 'Engine Repair',
      rating: 4.8,
      location: 'Downtown',
      status: 'Available',
      phone: '+1 234-567-8900',
      verified: true,
      emergencyResponse: true,
      completedJobs: 156,
      responseTime: '< 10 mins',
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      type: 'Car Wash',
      specialization: 'Premium Detailing',
      rating: 4.5,
      location: 'Westside',
      status: 'Busy',
      phone: '+1 234-567-8901',
      verified: true,
      emergencyResponse: false,
      completedJobs: 89,
      responseTime: '< 30 mins',
    },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [editingProvider, setEditingProvider] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    type: 'Mechanic',
    specialization: '',
    location: '',
    phone: '',
    emergencyResponse: false,
  });

  const handleEdit = (provider) => {
    setEditingProvider(provider);
    setFormData({
      name: provider.name,
      type: provider.type,
      specialization: provider.specialization,
      location: provider.location,
      phone: provider.phone,
      emergencyResponse: provider.emergencyResponse,
    });
    setShowModal(true);
  };

  const handleSubmit = () => {
    if (!formData.name || !formData.specialization || !formData.location || !formData.phone) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (editingProvider) {
      // Update existing provider
      setProviders(prev =>
        prev.map(p =>
          p.id === editingProvider.id
            ? {
                ...p,
                ...formData,
                status: p.status, // Preserve existing status
                rating: p.rating, // Preserve existing rating
                completedJobs: p.completedJobs, // Preserve existing stats
                verified: p.verified, // Preserve verification status
              }
            : p
        )
      );
      toast.success('Provider updated successfully');
    } else {
      // Add new provider
      const newProvider = {
        id: Date.now(),
        ...formData,
        rating: 0,
        status: 'Available',
        verified: false,
        completedJobs: 0,
        responseTime: 'N/A',
      };
      setProviders(prev => [...prev, newProvider]);
      toast.success('Provider added successfully');
    }

    setShowModal(false);
    setEditingProvider(null);
    setFormData({
      name: '',
      type: 'Mechanic',
      specialization: '',
      location: '',
      phone: '',
      emergencyResponse: false,
    });
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this provider?')) {
      setProviders(prev => prev.filter(p => p.id !== id));
      toast.success('Provider deleted successfully');
    }
  };

  const handleVerify = (id) => {
    setProviders(prev =>
      prev.map(p =>
        p.id === id ? { ...p, verified: true } : p
      )
    );
    toast.success('Provider verified successfully');
  };

  const filteredProviders = providers
    .filter(provider => 
      provider.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      provider.specialization.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter(provider => filterStatus === 'all' || provider.status.toLowerCase() === filterStatus)
    .filter(provider => filterType === 'all' || provider.type === filterType);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Service Providers</h2>
        <button
          onClick={() => {
            setEditingProvider(null);
            setFormData({
              name: '',
              type: 'Mechanic',
              specialization: '',
              location: '',
              phone: '',
              emergencyResponse: false,
            });
            setShowModal(true);
          }}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Tool className="h-5 w-5" />
          Add Provider
        </button>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search providers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border rounded-lg"
          >
            <option value="all">All Status</option>
            <option value="available">Available</option>
            <option value="busy">Busy</option>
          </select>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-4 py-2 border rounded-lg"
          >
            <option value="all">All Types</option>
            <option value="Mechanic">Mechanic</option>
            <option value="Car Wash">Car Wash</option>
            <option value="Towing">Towing</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProviders.map((provider) => (
          <div key={provider.id} className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-semibold text-gray-900">{provider.name}</h3>
                  {provider.verified && (
                    <Shield className="h-5 w-5 text-blue-600" />
                  )}
                </div>
                <p className="text-sm text-gray-500">{provider.type}</p>
              </div>
              <span
                className={`px-2 py-1 text-xs font-semibold rounded-full ${
                  provider.status === 'Available'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-yellow-100 text-yellow-800'
                }`}
              >
                {provider.status}
              </span>
            </div>

            <div className="mt-4 space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Tool className="h-4 w-4" />
                <span>{provider.specialization}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="h-4 w-4" />
                <span>{provider.location}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Phone className="h-4 w-4" />
                <span>{provider.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                <span>Response Time: {provider.responseTime}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Star className="h-4 w-4 text-yellow-400" />
                <span>{provider.rating} / 5.0</span>
                <span className="text-gray-400">({provider.completedJobs} jobs)</span>
              </div>
              {provider.emergencyResponse && (
                <div className="flex items-center gap-2 text-sm text-red-600">
                  <AlertTriangle className="h-4 w-4" />
                  <span>Emergency Response Available</span>
                </div>
              )}
            </div>

            <div className="mt-6 flex items-center gap-3">
              {!provider.verified ? (
                <button
                  onClick={() => handleVerify(provider.id)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <CheckCircle className="h-5 w-5" />
                  Verify
                </button>
              ) : (
                <button
                  onClick={() => handleEdit(provider)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Edit2 className="h-5 w-5" />
                  Edit
                </button>
              )}
              <button
                onClick={() => handleDelete(provider.id)}
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add/Edit Provider Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">
                {editingProvider ? 'Edit Provider' : 'Add New Provider'}
              </h3>
              <button
                onClick={() => {
                  setShowModal(false);
                  setEditingProvider(null);
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="Mechanic">Mechanic</option>
                  <option value="Car Wash">Car Wash</option>
                  <option value="Towing">Towing</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Specialization</label>
                <input
                  type="text"
                  value={formData.specialization}
                  onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Location</label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Phone</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.emergencyResponse}
                    onChange={(e) => setFormData({ ...formData, emergencyResponse: e.target.checked })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-600">Available for Emergency Response</span>
                </label>
              </div>

              <div className="flex items-center gap-3 mt-6">
                <button
                  onClick={handleSubmit}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  {editingProvider ? 'Save Changes' : 'Add Provider'}
                </button>
                <button
                  onClick={() => {
                    setShowModal(false);
                    setEditingProvider(null);
                  }}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceProviders;