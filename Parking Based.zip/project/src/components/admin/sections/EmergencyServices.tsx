import React from 'react';
import { AlertTriangle, PenTool as Tool, MapPin, Phone, Clock, CheckCircle } from 'lucide-react';

const EmergencyServices = () => {
  const emergencyRequests = [
    {
      id: 1,
      customer: 'David Brown',
      issue: 'Car breakdown',
      location: 'Highway 101, Mile 45',
      phone: '+1 234-567-8900',
      time: '10 mins ago',
      status: 'Unassigned',
    },
    {
      id: 2,
      customer: 'Emma Wilson',
      issue: 'Flat tire',
      location: 'Downtown, Main St',
      phone: '+1 234-567-8901',
      time: '15 mins ago',
      status: 'Assigned',
      mechanic: 'John Smith',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Emergency Services</h2>
        <div className="flex items-center gap-4">
          <select className="px-4 py-2 border rounded-lg">
            <option>All Status</option>
            <option>Unassigned</option>
            <option>Assigned</option>
            <option>Completed</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {emergencyRequests.map((request) => (
          <div
            key={request.id}
            className={`bg-white rounded-lg shadow-sm p-6 border-l-4 ${
              request.status === 'Unassigned' ? 'border-red-500' : 'border-yellow-500'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <AlertTriangle
                  className={`h-6 w-6 ${
                    request.status === 'Unassigned' ? 'text-red-500' : 'text-yellow-500'
                  }`}
                />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{request.customer}</h3>
                  <p className="text-sm text-gray-500">{request.issue}</p>
                </div>
              </div>
              <span
                className={`px-2 py-1 text-xs font-semibold rounded-full ${
                  request.status === 'Unassigned'
                    ? 'bg-red-100 text-red-800'
                    : 'bg-yellow-100 text-yellow-800'
                }`}
              >
                {request.status}
              </span>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="h-4 w-4" />
                <span>{request.location}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Phone className="h-4 w-4" />
                <span>{request.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                <span>{request.time}</span>
              </div>
              {request.mechanic && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Tool className="h-4 w-4" />
                  <span>Assigned to: {request.mechanic}</span>
                </div>
              )}
            </div>

            <div className="mt-6 flex items-center gap-4">
              {request.status === 'Unassigned' ? (
                <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Assign Mechanic
                </button>
              ) : (
                <button className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center justify-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  Mark as Completed
                </button>
              )}
              <button className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EmergencyServices;