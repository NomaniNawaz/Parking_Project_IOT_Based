import React from 'react';
import { Image, FileText, Edit2, Trash2, Plus } from 'lucide-react';

const ContentManagement = () => {
  const contentSections = [
    {
      id: 1,
      title: 'Homepage Hero',
      type: 'Banner',
      lastUpdated: '2024-03-14',
      status: 'Published',
    },
    {
      id: 2,
      title: 'Service Pricing',
      type: 'Pricing Table',
      lastUpdated: '2024-03-13',
      status: 'Draft',
    },
    {
      id: 3,
      title: 'About Us',
      type: 'Text Content',
      lastUpdated: '2024-03-12',
      status: 'Published',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Content Management</h2>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <Plus className="h-5 w-5" />
          Add New Content
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {contentSections.map((section) => (
          <div key={section.id} className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{section.title}</h3>
                <p className="text-sm text-gray-500">{section.type}</p>
              </div>
              <span
                className={`px-2 py-1 text-xs font-semibold rounded-full ${
                  section.status === 'Published'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-yellow-100 text-yellow-800'
                }`}
              >
                {section.status}
              </span>
            </div>

            <div className="mt-4 flex items-center gap-2 text-sm text-gray-600">
              <FileText className="h-4 w-4" />
              <span>Last updated: {section.lastUpdated}</span>
            </div>

            <div className="mt-6 flex items-center gap-3">
              <button className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <Edit2 className="h-4 w-4" />
                Edit
              </button>
              <button className="flex items-center justify-center p-2 text-red-600 hover:text-red-900">
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Media Library */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Media Library</h3>
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">
            <Image className="h-5 w-5" />
            Upload Media
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6].map((item) => (
            <div key={item} className="relative group">
              <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                <div className="w-full h-full flex items-center justify-center text-gray-400">
                  <Image className="h-8 w-8" />
                </div>
              </div>
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg">
                <button className="p-1 text-white hover:text-blue-200">
                  <Edit2 className="h-5 w-5" />
                </button>
                <button className="p-1 text-white hover:text-red-200">
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ContentManagement;