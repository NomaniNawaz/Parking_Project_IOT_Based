import React, { useState, useEffect } from 'react';
import { Bell, AlertTriangle, CheckCircle, Clock, Trash2, MoreVertical, Eye } from 'lucide-react';
import toast from 'react-hot-toast';

const Notifications = () => {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'emergency',
      title: 'New Emergency Request',
      message: 'User John Doe requires immediate assistance at Downtown Parking',
      time: '2 minutes ago',
      read: false,
      priority: 'high',
    },
    {
      id: 2,
      type: 'booking',
      title: 'New Parking Booking',
      message: 'Booking #12345 confirmed for Central Plaza Parking',
      time: '5 minutes ago',
      read: false,
      priority: 'medium',
    },
    {
      id: 3,
      type: 'system',
      title: 'System Update',
      message: 'New system update available. Please review and install.',
      time: '1 hour ago',
      read: true,
      priority: 'low',
    },
  ]);

  const [filter, setFilter] = useState('all');
  const [sortBy, setSortBy] = useState('time');

  useEffect(() => {
    // Simulate real-time notifications
    const interval = setInterval(() => {
      const newNotification = {
        id: Date.now(),
        type: Math.random() > 0.5 ? 'booking' : 'emergency',
        title: `New ${Math.random() > 0.5 ? 'Booking' : 'Emergency'} Alert`,
        message: `Auto-generated notification for testing - ${new Date().toLocaleTimeString()}`,
        time: 'Just now',
        read: false,
        priority: Math.random() > 0.5 ? 'high' : 'medium',
      };
      setNotifications(prev => [newNotification, ...prev]);
      toast.success('New notification received!');
    }, 30000); // Every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const handleMarkAsRead = (id: number) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
    toast.success('Notification marked as read');
  };

  const handleDelete = (id: number) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id));
    toast.success('Notification deleted');
  };

  const handleMarkAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notif => ({ ...notif, read: true }))
    );
    toast.success('All notifications marked as read');
  };

  const handleClearAll = () => {
    setNotifications([]);
    toast.success('All notifications cleared');
  };

  const filteredNotifications = notifications
    .filter(notif => filter === 'all' || notif.type === filter)
    .sort((a, b) => {
      if (sortBy === 'priority') {
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }
      return notifications.indexOf(a) - notifications.indexOf(b);
    });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-bold text-gray-900">Notifications</h2>
          <span className="px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-sm font-medium">
            {notifications.filter(n => !n.read).length} unread
          </span>
        </div>
        <div className="flex items-center gap-4">
          <select
            className="px-4 py-2 border rounded-lg"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All Types</option>
            <option value="emergency">Emergency</option>
            <option value="booking">Booking</option>
            <option value="system">System</option>
          </select>
          <select
            className="px-4 py-2 border rounded-lg"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="time">Sort by Time</option>
            <option value="priority">Sort by Priority</option>
          </select>
          <button
            onClick={handleMarkAllAsRead}
            className="px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            Mark All as Read
          </button>
          <button
            onClick={handleClearAll}
            className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            Clear All
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="divide-y divide-gray-200">
          {filteredNotifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-6 ${notification.read ? 'bg-white' : 'bg-blue-50'} hover:bg-gray-50 transition-colors`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className={`p-2 rounded-full ${
                    notification.type === 'emergency'
                      ? 'bg-red-100'
                      : notification.type === 'booking'
                      ? 'bg-green-100'
                      : 'bg-yellow-100'
                  }`}>
                    {notification.type === 'emergency' ? (
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                    ) : notification.type === 'booking' ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <Bell className="h-5 w-5 text-yellow-600" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-semibold text-gray-900">{notification.title}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        notification.priority === 'high'
                          ? 'bg-red-100 text-red-600'
                          : notification.priority === 'medium'
                          ? 'bg-yellow-100 text-yellow-600'
                          : 'bg-green-100 text-green-600'
                      }`}>
                        {notification.priority}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-gray-600">{notification.message}</p>
                    <div className="mt-2 flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>{notification.time}</span>
                      </div>
                      {!notification.read && (
                        <button
                          onClick={() => handleMarkAsRead(notification.id)}
                          className="flex items-center gap-1 text-blue-600 hover:text-blue-700"
                        >
                          <Eye className="h-4 w-4" />
                          <span>Mark as read</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDelete(notification.id)}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                  <div className="relative group">
                    <button className="p-2 text-gray-400 hover:text-gray-600">
                      <MoreVertical className="h-5 w-5" />
                    </button>
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg hidden group-hover:block">
                      <div className="py-1">
                        <button className="block w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-left">
                          View Details
                        </button>
                        <button className="block w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 text-left">
                          Snooze
                        </button>
                        <button className="block w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100 text-left">
                          Block Similar
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Notifications;