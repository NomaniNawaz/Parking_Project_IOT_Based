import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FileText, MapPin, User, CheckCircle, XCircle, AlertTriangle, Car, DollarSign, Image } from 'lucide-react';
import { supabase } from '../../../lib/supabase';
import { DataTable } from '../DataTable';
import ConfirmDialog from '../ConfirmDialog';
import toast from 'react-hot-toast';
import type { ColumnDef } from '@tanstack/react-table';

interface ParkingSpace {
  id: string;
  name: string;
  location: {
    address: string;
    latitude: number;
    longitude: number;
  };
  total_slots: number;
  price_per_hour: number;
  status: string;
  created_at: string;
  owner: {
    full_name: string;
    email: string;
  };
  photos: string[];
  documents: string[];
}

const ParkingRegistrations = () => {
  const [parkingSpaces, setParkingSpaces] = useState<ParkingSpace[]>([]);
  const [loading, setLoading] = useState(true);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [selectedSpace, setSelectedSpace] = useState<ParkingSpace | null>(null);
  const [dialogAction, setDialogAction] = useState<'approve' | 'reject'>('approve');

  const columns: ColumnDef<ParkingSpace>[] = [
    {
      accessorKey: 'name',
      header: 'Parking Name',
    },
    {
      accessorKey: 'owner.full_name',
      header: 'Owner',
    },
    {
      accessorKey: 'location.address',
      header: 'Location',
    },
    {
      accessorKey: 'total_slots',
      header: 'Total Slots',
    },
    {
      accessorKey: 'price_per_hour',
      header: 'Price/Hour',
      cell: ({ row }) => (
        <span>${row.original.price_per_hour}</span>
      ),
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => (
        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
          row.original.status === 'approved' ? 'bg-green-100 text-green-800' :
          row.original.status === 'rejected' ? 'bg-red-100 text-red-800' :
          'bg-yellow-100 text-yellow-800'
        }`}>
          {row.original.status.charAt(0).toUpperCase() + row.original.status.slice(1)}
        </span>
      ),
    },
  ];

  useEffect(() => {
    fetchParkingSpaces();
  }, []);

  const fetchParkingSpaces = async () => {
    try {
      const { data, error } = await supabase
        .from('parking_spaces')
        .select(`
          *,
          owner:profiles(full_name, email)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setParkingSpaces(data || []);
    } catch (error) {
      console.error('Error fetching parking spaces:', error);
      toast.error('Failed to load parking spaces');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (space: ParkingSpace, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('parking_spaces')
        .update({ status: newStatus })
        .eq('id', space.id);

      if (error) throw error;

      setParkingSpaces(prev =>
        prev.map(p =>
          p.id === space.id ? { ...p, status: newStatus } : p
        )
      );

      toast.success(`Parking space ${newStatus}`);
    } catch (error) {
      console.error('Error updating parking space:', error);
      toast.error('Failed to update parking space');
    }
  };

  const handleAction = (space: ParkingSpace, action: 'approve' | 'reject') => {
    setSelectedSpace(space);
    setDialogAction(action);
    setShowConfirmDialog(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Parking Space Registrations</h2>
      </div>

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-6">
          <DataTable
            data={parkingSpaces}
            columns={columns}
            onEdit={(space) => handleAction(space, 'approve')}
          />
        </div>
      </div>

      {selectedSpace && (
        <ConfirmDialog
          isOpen={showConfirmDialog}
          onClose={() => setShowConfirmDialog(false)}
          onConfirm={() => {
            handleStatusChange(selectedSpace, dialogAction === 'approve' ? 'approved' : 'rejected');
            setShowConfirmDialog(false);
          }}
          title={`${dialogAction === 'approve' ? 'Approve' : 'Reject'} Parking Space`}
          message={`Are you sure you want to ${dialogAction} the parking space "${selectedSpace.name}"?`}
          confirmLabel={dialogAction === 'approve' ? 'Approve' : 'Reject'}
          cancelLabel="Cancel"
          type={dialogAction === 'approve' ? 'info' : 'danger'}
        />
      )}
    </div>
  );
};

export default ParkingRegistrations;