import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FileText, MapPin, User, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '../../../lib/supabase';
import { DataTable } from '../DataTable';
import ConfirmDialog from '../ConfirmDialog';
import toast from 'react-hot-toast';
import type { ColumnDef } from '@tanstack/react-table';

interface Registration {
  id: string;
  property_name: string;
  address: string;
  area_size: number;
  property_type: string;
  status: string;
  created_at: string;
  owner: {
    full_name: string;
    email: string;
  };
}

const LandRegistration = () => {
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [loading, setLoading] = useState(true);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [selectedRegistration, setSelectedRegistration] = useState<Registration | null>(null);

  const columns: ColumnDef<Registration>[] = [
    {
      accessorKey: 'property_name',
      header: 'Property Name',
    },
    {
      accessorKey: 'owner.full_name',
      header: 'Owner',
    },
    {
      accessorKey: 'address',
      header: 'Address',
    },
    {
      accessorKey: 'area_size',
      header: 'Area (sq ft)',
    },
    {
      accessorKey: 'property_type',
      header: 'Type',
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => (
        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
          row.original.status === 'approved' ? 'bg-green-100 text-green-800' :
          row.original.status === 'rejected' ? 'bg-red-100 text-red-800' :
          'bg-yellow-100 text-yellow-800'
        }`}>
          {row.original.status.charAt(0).toUpperCase() + row.original.status.slice(1)}
        </span>
      ),
    },
  ];

  useEffect(() => {
    fetchRegistrations();
  }, []);

  const fetchRegistrations = async () => {
    try {
      const { data, error } = await supabase
        .from('parking_registration')
        .select(`
          *,
          owner:profiles(full_name, email)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRegistrations(data || []);
    } catch (error) {
      console.error('Error fetching registrations:', error);
      toast.error('Failed to load registrations');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (registration: Registration, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('parking_registration')
        .update({ status: newStatus })
        .eq('id', registration.id);

      if (error) throw error;

      setRegistrations(prev =>
        prev.map(r =>
          r.id === registration.id ? { ...r, status: newStatus } : r
        )
      );

      toast.success(`Registration ${newStatus}`);
    } catch (error) {
      console.error('Error updating registration:', error);
      toast.error('Failed to update registration');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Land Registration Management</h2>
      </div>

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-6">
          <DataTable
            data={registrations}
            columns={columns}
            onEdit={(registration) => {
              setSelectedRegistration(registration);
              setShowConfirmDialog(true);
            }}
          />
        </div>
      </div>

      <ConfirmDialog
        isOpen={showConfirmDialog}
        onClose={() => setShowConfirmDialog(false)}
        onConfirm={() => {
          if (selectedRegistration) {
            handleStatusChange(selectedRegistration, 'approved');
          }
          setShowConfirmDialog(false);
        }}
        title="Approve Registration"
        message={`Are you sure you want to approve the registration for ${selectedRegistration?.property_name}?`}
        confirmLabel="Approve"
        cancelLabel="Cancel"
        type="info"
      />
    </div>
  );
};

export default LandRegistration;