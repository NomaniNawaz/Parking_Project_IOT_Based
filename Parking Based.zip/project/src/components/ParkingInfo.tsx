import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Info, Clock, CreditCard, Shield, Phone, AlertTriangle, ChevronDown } from 'lucide-react';
import ParkingMap from './ParkingMap';

interface ExpandableSectionProps {
  title: string;
  icon: React.ElementType;
  children: React.ReactNode;
  isOpen: boolean;
  onToggle: () => void;
}

const ExpandableSection: React.FC<ExpandableSectionProps> = ({ title, icon: Icon, children, isOpen, onToggle }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full px-6 py-4 flex items-center justify-between bg-white hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <Icon className="h-5 w-5 text-blue-600" />
          <span className="font-medium text-gray-900">{title}</span>
        </div>
        <ChevronDown className={`h-5 w-5 text-gray-400 transition-transform ${isOpen ? 'transform rotate-180' : ''}`} />
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="px-6 py-4 border-t">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const ParkingInfo = () => {
  const [openSection, setOpenSection] = useState<string | null>(null);
  const [showMap, setShowMap] = useState(false);

  const toggleSection = (section: string) => {
    setOpenSection(openSection === section ? null : section);
  };

  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column */}
          <div className="space-y-6">
            {/* Find Parking Section */}
            <ExpandableSection
              title="Find Parking"
              icon={MapPin}
              isOpen={openSection === 'findParking'}
              onToggle={() => toggleSection('findParking')}
            >
              <div className="space-y-4">
                <button
                  onClick={() => setShowMap(true)}
                  className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  View Interactive Map
                </button>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-900">Hourly Rate</h4>
                    <p className="text-gray-600">From ₹50/hour</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-900">Operating Hours</h4>
                    <p className="text-gray-600">24/7</p>
                  </div>
                </div>
              </div>
            </ExpandableSection>

            {/* How It Works Section */}
            <ExpandableSection
              title="How It Works"
              icon={Info}
              isOpen={openSection === 'howItWorks'}
              onToggle={() => toggleSection('howItWorks')}
            >
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600 font-medium">1</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Search & Book</h4>
                    <p className="text-gray-600">Find available spots and book instantly</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600 font-medium">2</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Park Your Vehicle</h4>
                    <p className="text-gray-600">Follow directions to your reserved spot</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600 font-medium">3</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Pay & Go</h4>
                    <p className="text-gray-600">Contactless payment when you leave</p>
                  </div>
                </div>
              </div>
            </ExpandableSection>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* 24/7 Availability Section */}
            <ExpandableSection
              title="24/7 Availability"
              icon={Clock}
              isOpen={openSection === 'availability'}
              onToggle={() => toggleSection('availability')}
            >
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <Clock className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                    <h4 className="font-medium text-gray-900">Real-time Updates</h4>
                    <p className="text-sm text-gray-600">Live availability status</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <Phone className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                    <h4 className="font-medium text-gray-900">24/7 Support</h4>
                    <p className="text-sm text-gray-600">Always here to help</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <AlertTriangle className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                    <h4 className="font-medium text-gray-900">Emergency Access</h4>
                    <p className="text-sm text-gray-600">Immediate assistance</p>
                  </div>
                </div>
                <div className="mt-4">
                  <h4 className="font-medium text-gray-900 mb-2">Emergency Contact</h4>
                  <a
                    href="tel:+1234567890"
                    className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
                  >
                    <Phone className="h-4 w-4" />
                    <span>+1 (234) 567-890</span>
                  </a>
                </div>
              </div>
            </ExpandableSection>

            {/* Secure Payments Section */}
            <ExpandableSection
              title="Secure Payments"
              icon={CreditCard}
              isOpen={openSection === 'payments'}
              onToggle={() => toggleSection('payments')}
            >
              <div className="space-y-4">
                <div className="flex items-center gap-4 bg-gray-50 p-4 rounded-lg">
                  <Shield className="h-6 w-6 text-green-600" />
                  <div>
                    <h4 className="font-medium text-gray-900">Bank-Level Security</h4>
                    <p className="text-sm text-gray-600">Your payments are always secure</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Payment Methods</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>Credit/Debit Cards</li>
                      <li>Digital Wallets</li>
                      <li>Net Banking</li>
                      <li>UPI</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Features</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>Instant Confirmation</li>
                      <li>Digital Receipts</li>
                      <li>Auto-payment</li>
                      <li>Refund Protection</li>
                    </ul>
                  </div>
                </div>
              </div>
            </ExpandableSection>
          </div>
        </div>

        {/* Map Modal */}
        <AnimatePresence>
          {showMap && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
            >
              <motion.div
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.9 }}
                className="bg-white rounded-lg shadow-xl w-full max-w-4xl m-4"
              >
                <div className="p-4 border-b flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">Available Parking Spots</h3>
                  <button
                    onClick={() => setShowMap(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                <div className="h-[600px]">
                  <ParkingMap />
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ParkingInfo;