import React from 'react';
import { Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const plans = [
  {
    name: "Basic",
    price: "Free",
    features: [
      "Find nearby parking spots",
      "Real-time availability",
      "Basic notifications",
      "Pay-as-you-go pricing"
    ]
  },
  {
    name: "Premium",
    price: "₹299/month",
    features: [
      "All Basic features",
      "Priority booking",
      "Discounted rates",
      "24/7 premium support",
      "Advance reservations",
      "Parking history"
    ]
  },
  {
    name: "Business",
    price: "Custom",
    features: [
      "All Premium features",
      "Multiple vehicle support",
      "Employee parking management",
      "Custom billing options",
      "API access",
      "Dedicated account manager"
    ]
  }
];

const Pricing = () => {
  const navigate = useNavigate();

  const handleGetStarted = (planName: string) => {
    // Navigate to payment page with plan details
    navigate('/payment', { state: { plan: planName } });
  };

  return (
    <div className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Pricing</h2>
          <p className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Choose Your Plan
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Simple, transparent pricing for everyone
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className="relative p-8 bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-lg transition-shadow"
            >
              <div className="mb-8">
                <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
                <p className="mt-4 text-3xl font-extrabold text-blue-600">{plan.price}</p>
              </div>
              <ul className="space-y-4">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>
              <button 
                onClick={() => handleGetStarted(plan.name)}
                className="mt-8 w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Get Started
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Pricing;