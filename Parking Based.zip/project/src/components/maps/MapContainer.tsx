import React, { useState, useEffect } from 'react';
import { MapPin, Wifi, WifiOff, Compass } from 'lucide-react';
import OnlineMap from './OnlineMap';
import OfflineMap from './OfflineMap';
import { useOnlineStatus } from '../../hooks/useOnlineStatus';
import toast from 'react-hot-toast';

interface MapContainerProps {
  center?: [number, number];
  zoom?: number;
  markers?: Array<{
    id: string;
    position: [number, number];
    title: string;
    type: 'parking' | 'user';
  }>;
  onMarkerClick?: (id: string) => void;
}

const MapContainer: React.FC<MapContainerProps> = ({
  center = [40.7128, -74.0060],
  zoom = 13,
  markers = [],
  onMarkerClick
}) => {
  const isOnline = useOnlineStatus();
  const [forceOffline, setForceOffline] = useState(false);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation([position.coords.latitude, position.coords.longitude]);
        },
        (error) => {
          console.error('Error getting location:', error);
          toast.error('Unable to get your location');
        }
      );
    }
  }, []);

  const handleModeToggle = () => {
    setForceOffline(!forceOffline);
    toast.success(`Switched to ${!forceOffline ? 'offline' : 'online'} mode`);
  };

  const handleCenterOnUser = () => {
    if (userLocation) {
      // Implementation depends on the map library being used
      toast.success('Centered on your location');
    } else {
      toast.error('User location not available');
    }
  };

  const effectivelyOffline = !isOnline || forceOffline;

  return (
    <div className="relative h-full w-full">
      {/* Map Mode Toggle */}
      <div className="absolute top-4 right-4 z-10 space-y-2">
        <button
          onClick={handleModeToggle}
          className={`p-2 rounded-full shadow-lg ${
            effectivelyOffline
              ? 'bg-gray-700 text-white'
              : 'bg-white text-gray-700'
          } hover:opacity-90 transition-colors`}
          title={`Switch to ${effectivelyOffline ? 'online' : 'offline'} mode`}
        >
          {effectivelyOffline ? (
            <WifiOff className="h-6 w-6" />
          ) : (
            <Wifi className="h-6 w-6" />
          )}
        </button>

        <button
          onClick={handleCenterOnUser}
          className="p-2 rounded-full shadow-lg bg-white text-gray-700 hover:opacity-90 transition-colors"
          title="Center on your location"
        >
          <Compass className="h-6 w-6" />
        </button>
      </div>

      {/* Offline Mode Banner */}
      {effectivelyOffline && (
        <div className="absolute top-4 left-4 z-10 bg-yellow-100 text-yellow-800 px-4 py-2 rounded-lg shadow-lg">
          <p className="text-sm font-medium">Offline Mode</p>
        </div>
      )}

      {/* Map Component */}
      <div className="h-full w-full">
        {effectivelyOffline ? (
          <OfflineMap
            center={center}
            zoom={zoom}
            markers={markers}
            userLocation={userLocation}
            onMarkerClick={onMarkerClick}
          />
        ) : (
          <OnlineMap
            center={center}
            zoom={zoom}
            markers={markers}
            userLocation={userLocation}
            onMarkerClick={onMarkerClick}
          />
        )}
      </div>

      {/* Loading Indicator */}
      {!userLocation && (
        <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-75">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
        </div>
      )}
    </div>
  );
};

export default MapContainer;