import React, { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { MapPin } from 'lucide-react';

interface OnlineMapProps {
  center: [number, number];
  zoom: number;
  markers?: Array<{
    id: string;
    position: [number, number];
    title: string;
    type: 'parking' | 'user';
  }>;
  userLocation: [number, number] | null;
  onMarkerClick?: (id: string) => void;
}

const OnlineMap: React.FC<OnlineMapProps> = ({
  center,
  zoom,
  markers = [],
  userLocation,
  onMarkerClick
}) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markersRef = useRef<{ [key: string]: mapboxgl.Marker }>({});

  useEffect(() => {
    if (!mapContainer.current) return;

    mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_TOKEN;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: center,
      zoom: zoom
    });

    // Add navigation controls
    map.current.addControl(new mapboxgl.NavigationControl());

    return () => {
      if (map.current) {
        map.current.remove();
      }
    };
  }, []);

  // Update markers when they change
  useEffect(() => {
    if (!map.current) return;

    // Remove old markers
    Object.values(markersRef.current).forEach(marker => marker.remove());
    markersRef.current = {};

    // Add new markers
    markers.forEach(marker => {
      const el = document.createElement('div');
      el.className = 'marker';
      el.innerHTML = `<div class="p-2 rounded-full ${
        marker.type === 'parking' ? 'bg-blue-500' : 'bg-red-500'
      } text-white cursor-pointer">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          ${marker.type === 'parking' ? 
            '<path d="M5 5h14v14H5z"/><path d="M9 5v14"/><path d="M9 9h4"/><path d="M13 9v4"/>' :
            '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>'
          }
        </svg>
      </div>`;

      el.addEventListener('click', () => onMarkerClick?.(marker.id));

      const mapMarker = new mapboxgl.Marker(el)
        .setLngLat([marker.position[1], marker.position[0]])
        .setPopup(new mapboxgl.Popup().setHTML(marker.title))
        .addTo(map.current!);

      markersRef.current[marker.id] = mapMarker;
    });
  }, [markers]);

  // Update user location marker
  useEffect(() => {
    if (!map.current || !userLocation) return;

    if (markersRef.current.userLocation) {
      markersRef.current.userLocation.remove();
    }

    const el = document.createElement('div');
    el.className = 'marker';
    el.innerHTML = `<div class="p-2 rounded-full bg-blue-600 text-white">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/>
      </svg>
    </div>`;

    markersRef.current.userLocation = new mapboxgl.Marker(el)
      .setLngLat([userLocation[1], userLocation[0]])
      .addTo(map.current);
  }, [userLocation]);

  return <div ref={mapContainer} className="h-full w-full" />;
};

export default OnlineMap;