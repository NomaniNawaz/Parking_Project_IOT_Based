import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User, Bell, Settings, History, LogOut, Shield } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { UserProfile } from '../../types/auth';
import toast from 'react-hot-toast';

const UserDashboard = () => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [recentActivity] = useState([
    { type: 'login', date: new Date().toISOString(), location: 'New York, US' },
    { type: 'password_changed', date: new Date(Date.now() - 86400000).toISOString(), location: 'New York, US' },
    { type: 'profile_updated', date: new Date(Date.now() - 172800000).toISOString(), location: 'New York, US' },
  ]);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('No user found');

        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) throw error;
        setProfile(profile);
      } catch (error) {
        console.error('Error fetching profile:', error);
        toast.error('Failed to load profile');
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      window.location.href = '/signin';
    } catch (error) {
      console.error('Error logging out:', error);
      toast.error('Failed to log out');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center">
                <User className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Welcome back, {profile?.fullName}
                </h1>
                <p className="text-gray-500">Last login: {new Date(profile?.lastLoginAt || '').toLocaleString()}</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            >
              <LogOut className="h-5 w-5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="col-span-2 space-y-8">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button className="flex items-center gap-3 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <Bell className="h-6 w-6 text-blue-600" />
                  <div className="text-left">
                    <h3 className="font-medium text-gray-900">Notifications</h3>
                    <p className="text-sm text-gray-500">Manage your alerts</p>
                  </div>
                </button>
                <button className="flex items-center gap-3 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <Settings className="h-6 w-6 text-blue-600" />
                  <div className="text-left">
                    <h3 className="font-medium text-gray-900">Settings</h3>
                    <p className="text-sm text-gray-500">Update preferences</p>
                  </div>
                </button>
                <button className="flex items-center gap-3 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <Shield className="h-6 w-6 text-blue-600" />
                  <div className="text-left">
                    <h3 className="font-medium text-gray-900">Security</h3>
                    <p className="text-sm text-gray-500">Manage account security</p>
                  </div>
                </button>
                <button className="flex items-center gap-3 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <History className="h-6 w-6 text-blue-600" />
                  <div className="text-left">
                    <h3 className="font-medium text-gray-900">Activity</h3>
                    <p className="text-sm text-gray-500">View recent actions</p>
                  </div>
                </button>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                        {activity.type === 'login' && <User className="h-5 w-5 text-blue-600" />}
                        {activity.type === 'password_changed' && <Shield className="h-5 w-5 text-blue-600" />}
                        {activity.type === 'profile_updated' && <Settings className="h-5 w-5 text-blue-600" />}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">
                          {activity.type === 'login' && 'Successful login'}
                          {activity.type === 'password_changed' && 'Password changed'}
                          {activity.type === 'profile_updated' && 'Profile updated'}
                        </p>
                        <p className="text-sm text-gray-500">{activity.location}</p>
                      </div>
                    </div>
                    <p className="text-sm text-gray-500">
                      {new Date(activity.date).toLocaleString()}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* Profile & Settings */}
          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Profile Information</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Full Name</label>
                  <p className="mt-1 text-gray-900">{profile?.fullName}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <p className="mt-1 text-gray-900">{profile?.email}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Member Since</label>
                  <p className="mt-1 text-gray-900">
                    {new Date(profile?.createdAt || '').toLocaleDateString()}
                  </p>
                </div>
              </div>
              <button className="mt-6 w-full flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                <Settings className="h-5 w-5" />
                <span>Edit Profile</span>
              </button>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Account Preferences</h2>
              <div className="space-y-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={profile?.preferences?.notifications}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-sm text-gray-900">Email Notifications</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={profile?.preferences?.newsletter}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-sm text-gray-900">Newsletter</span>
                </label>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Theme</label>
                  <select
                    value={profile?.preferences?.theme}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  >
                    <option value="light">Light</option>
                    <option value="dark">Dark</option>
                  </select>
                </div>
              </div>
              <button className="mt-6 w-full flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                <Save className="h-5 w-5" />
                <span>Save Preferences</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;