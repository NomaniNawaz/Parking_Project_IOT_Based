import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Car, MapPin, History, Settings, ArrowRight, Shield, Clock } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import toast from 'react-hot-toast';

const Dashboard = () => {
  const navigate = useNavigate();
  const [hasRegisteredSpace, setHasRegisteredSpace] = useState(false);
  const [loading, setLoading] = useState(true);
  const [recentActivity] = useState([
    { type: 'booking', date: new Date(), location: 'Downtown Parking' },
    { type: 'registration', date: new Date(Date.now() - 86400000), location: 'City Center' }
  ]);

  useEffect(() => {
    checkRegisteredSpace();
  }, []);

  const checkRegisteredSpace = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { data: spaces, error } = await supabase
        .from('parking_spaces')
        .select('id')
        .eq('owner_id', user.id)
        .limit(1);

      if (error) throw error;
      setHasRegisteredSpace(spaces && spaces.length > 0);

      if (spaces && spaces.length > 0) {
        toast.success('Welcome back! Redirecting to your parking dashboard...');
        setTimeout(() => navigate('/parking-dashboard'), 2000);
      }
    } catch (error) {
      console.error('Error checking registered space:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-gray-50 py-12"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to ParkEase</h1>
          <p className="text-lg text-gray-600">Choose what you'd like to do today</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Register Parking Space Card */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="bg-white rounded-2xl shadow-xl overflow-hidden"
          >
            <div className="p-8">
              <div className="h-16 w-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                <Car className="h-8 w-8 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Register Your Parking Space</h2>
              <p className="text-gray-600 mb-6">
                Earn money by listing your unused parking space. Easy registration process with complete management tools.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center text-gray-600">
                  <Shield className="h-5 w-5 text-green-500 mr-3" />
                  <span>Secure payments</span>
                </li>
                <li className="flex items-center text-gray-600">
                  <Clock className="h-5 w-5 text-green-500 mr-3" />
                  <span>24/7 support</span>
                </li>
                <li className="flex items-center text-gray-600">
                  <Settings className="h-5 w-5 text-green-500 mr-3" />
                  <span>Easy management</span>
                </li>
              </ul>
              <Link
                to="/register-parking"
                className="flex items-center justify-between w-full px-6 py-3 text-lg font-medium text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition-colors"
              >
                Start Registration
                <ArrowRight className="h-5 w-5" />
              </Link>
            </div>
          </motion.div>

          {/* Find Parking Card */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="bg-white rounded-2xl shadow-xl overflow-hidden"
          >
            <div className="p-8">
              <div className="h-16 w-16 bg-green-100 rounded-2xl flex items-center justify-center mb-6">
                <MapPin className="h-8 w-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Find Parking</h2>
              <p className="text-gray-600 mb-6">
                Discover convenient parking spots near your destination. Real-time availability and instant booking.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center text-gray-600">
                  <MapPin className="h-5 w-5 text-green-500 mr-3" />
                  <span>Real-time availability</span>
                </li>
                <li className="flex items-center text-gray-600">
                  <Shield className="h-5 w-5 text-green-500 mr-3" />
                  <span>Guaranteed spots</span>
                </li>
                <li className="flex items-center text-gray-600">
                  <Clock className="h-5 w-5 text-green-500 mr-3" />
                  <span>Instant booking</span>
                </li>
              </ul>
              <Link
                to="/find-parking"
                className="flex items-center justify-between w-full px-6 py-3 text-lg font-medium text-white bg-green-600 rounded-xl hover:bg-green-700 transition-colors"
              >
                Find Parking Now
                <ArrowRight className="h-5 w-5" />
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Recent Activity</h3>
            <History className="h-5 w-5 text-gray-400" />
          </div>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center">
                  {activity.type === 'booking' ? (
                    <Car className="h-5 w-5 text-blue-500 mr-3" />
                  ) : (
                    <MapPin className="h-5 w-5 text-green-500 mr-3" />
                  )}
                  <div>
                    <p className="font-medium text-gray-900">
                      {activity.type === 'booking' ? 'Parking Booked' : 'Space Registered'}
                    </p>
                    <p className="text-sm text-gray-500">{activity.location}</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">
                  {activity.date.toLocaleDateString()}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default Dashboard;