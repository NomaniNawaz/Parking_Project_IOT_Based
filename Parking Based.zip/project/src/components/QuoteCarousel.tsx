import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const quotes = [
  {
    text: "The best parking experience is the one you don't have to think about.",
    author: "Sarah Chen",
    role: "Urban Planning Expert"
  },
  {
    text: "Smart parking isn't just about convenience; it's about creating a more livable city.",
    author: "Michael Rodriguez",
    role: "City Infrastructure Specialist"
  },
  {
    text: "Time spent searching for parking is time wasted. Let technology guide the way.",
    author: "Dr. Emily Watson",
    role: "Transportation Researcher"
  },
  {
    text: "The future of parking is not about spaces; it's about seamless experiences.",
    author: "James Park",
    role: "Smart City Architect"
  },
  {
    text: "Every minute saved in parking is a minute given back to the community.",
    author: "Lisa Thompson",
    role: "Community Development Leader"
  }
];

const QuoteCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isDragging, setIsDragging] = useState(false);

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  const paginate = useCallback((newDirection: number) => {
    setDirection(newDirection);
    setCurrentIndex((prevIndex) => {
      let nextIndex = prevIndex + newDirection;
      if (nextIndex >= quotes.length) nextIndex = 0;
      if (nextIndex < 0) nextIndex = quotes.length - 1;
      return nextIndex;
    });
  }, []);

  useEffect(() => {
    if (isDragging) return;

    const timer = setInterval(() => {
      paginate(1);
    }, 5000);

    return () => clearInterval(timer);
  }, [paginate, isDragging]);

  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <div className="bg-blue-600 rounded-full p-3 shadow-lg">
            <Quote className="w-6 h-6 text-white" />
          </div>
        </div>

        <div className="relative h-64">
          <AnimatePresence initial={false} custom={direction}>
            <motion.div
              key={currentIndex}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.2 }
              }}
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={1}
              onDragStart={() => setIsDragging(true)}
              onDragEnd={(e, { offset, velocity }) => {
                setIsDragging(false);
                const swipe = swipePower(offset.x, velocity.x);

                if (swipe < -swipeConfidenceThreshold) {
                  paginate(1);
                } else if (swipe > swipeConfidenceThreshold) {
                  paginate(-1);
                }
              }}
              className="absolute w-full"
            >
              <div className="text-center">
                <p className="text-2xl md:text-3xl font-medium text-gray-900 italic">
                  "{quotes[currentIndex].text}"
                </p>
                <div className="mt-8">
                  <p className="text-lg font-semibold text-blue-600">
                    {quotes[currentIndex].author}
                  </p>
                  <p className="text-sm text-gray-600">
                    {quotes[currentIndex].role}
                  </p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="absolute top-1/2 left-0 transform -translate-y-1/2 -translate-x-12">
          <button
            onClick={() => paginate(-1)}
            className="p-2 rounded-full bg-white shadow-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <ChevronLeft className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="absolute top-1/2 right-0 transform -translate-y-1/2 translate-x-12">
          <button
            onClick={() => paginate(1)}
            className="p-2 rounded-full bg-white shadow-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <ChevronRight className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="flex justify-center mt-8 space-x-2">
          {quotes.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setDirection(index > currentIndex ? 1 : -1);
                setCurrentIndex(index);
              }}
              className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                index === currentIndex ? 'bg-blue-600' : 'bg-gray-300'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuoteCarousel;