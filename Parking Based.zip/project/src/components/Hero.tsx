import React, { useState } from 'react';
import { MapPin, Search } from 'lucide-react';
import toast from 'react-hot-toast';

const Hero = () => {
  const [location, setLocation] = useState('');

  const handleSearch = () => {
    if (!location) {
      toast.error('Please enter a location');
      return;
    }
    // Simulate finding nearby parking spots
    toast.success(`Searching for parking spots near ${location}`);
    // In a real app, this would trigger an API call to find nearby parking spots
  };

  const handleCurrentLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
          toast.success('Location detected! Searching for nearby parking spots...');
        },
        () => {
          toast.error('Unable to get your location. Please enter it manually.');
        }
      );
    } else {
      toast.error('Geolocation is not supported by your browser');
    }
  };

  return (
    <div className="relative bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
          <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
            <div className="sm:text-center lg:text-left">
              <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                <span className="block">Find and reserve</span>
                <span className="block text-blue-600">parking spots instantly</span>
              </h1>
              <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                Secure your parking spot in advance. No more circling around looking for parking. Easy booking, guaranteed spots, and hassle-free parking.
              </p>
              <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                <div className="rounded-md shadow">
                  <div className="w-full flex items-center justify-between gap-2 max-w-md px-4 py-3 border border-transparent text-base font-medium rounded-md bg-white border-gray-300">
                    <MapPin className="h-5 w-5 text-blue-600 flex-shrink-0" />
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="Enter location..."
                      className="w-full outline-none text-gray-900"
                    />
                    <button
                      onClick={handleCurrentLocation}
                      className="flex-shrink-0 px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                    >
                      Current Location
                    </button>
                    <button
                      onClick={handleSearch}
                      className="flex-shrink-0 p-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                    >
                      <Search className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
      <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
        <img
          className="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full"
          src="https://images.unsplash.com/photo-1470224114660-3f6686c562eb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80"
          alt="Modern parking garage"
        />
      </div>
    </div>
  );
}

export default Hero;