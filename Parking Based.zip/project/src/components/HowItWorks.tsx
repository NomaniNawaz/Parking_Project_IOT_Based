import React from 'react';
import { motion } from 'framer-motion';
import { Search, MapPin, CreditCard, Car } from 'lucide-react';

const steps = [
  {
    icon: Search,
    title: "Search Location",
    description: "Enter your destination or use current location to find nearby parking spots.",
    color: "bg-blue-100 text-blue-600",
  },
  {
    icon: MapPin,
    title: "Choose Parking",
    description: "View available spots on the map, compare prices, and check real-time availability.",
    color: "bg-green-100 text-green-600",
  },
  {
    icon: CreditCard,
    title: "Book & Pay",
    description: "Reserve your spot instantly with secure online payment. Multiple payment options available.",
    color: "bg-purple-100 text-purple-600",
  },
  {
    icon: Car,
    title: "Park with Ease",
    description: "Follow the directions to your spot. Show your digital ticket on arrival. No paper needed!",
    color: "bg-orange-100 text-orange-600",
  },
];

const HowItWorks = () => {
  return (
    <div className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-base text-blue-600 font-semibold tracking-wide uppercase"
          >
            How It Works
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl"
          >
            Simple steps to start parking
          </motion.p>
        </div>

        <div className="mt-20">
          <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-4">
            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 + 0.5 }}
                className="relative"
              >
                <div className="relative">
                  <div className={`absolute z-10 flex items-center justify-center w-16 h-16 rounded-full ${step.color}`}>
                    <step.icon className="w-8 h-8" />
                  </div>
                  {index < steps.length - 1 && (
                    <div className="hidden lg:block absolute top-8 left-16 w-full border-t-2 border-dashed border-gray-200" />
                  )}
                  <div className="relative pl-20">
                    <h3 className="text-xl font-bold text-gray-900">{step.title}</h3>
                    <p className="mt-3 text-base text-gray-500">{step.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="mt-20 text-center"
        >
          <button className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors">
            Start Parking Now
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default HowItWorks;