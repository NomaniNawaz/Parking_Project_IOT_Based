import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Car, Wrench, Truck } from 'lucide-react';

const emergencyServices = [
  {
    icon: Car,
    title: 'Car Breakdown',
    description: 'Immediate assistance for vehicle breakdowns, including battery, fuel, and tire issues.',
    color: 'bg-red-100 text-red-600',
  },
  {
    icon: Wrench,
    title: 'Mechanical Issues',
    description: 'Expert mechanics available 24/7 for urgent repairs and technical problems.',
    color: 'bg-orange-100 text-orange-600',
  },
  {
    icon: Truck,
    title: 'Towing Service',
    description: 'Quick and reliable towing service to the nearest garage or your preferred location.',
    color: 'bg-yellow-100 text-yellow-600',
  },
  {
    icon: Phone,
    title: '24/7 Support',
    description: 'Round-the-clock customer support for any parking-related emergencies.',
    color: 'bg-green-100 text-green-600',
  },
];

const Emergency = () => {
  return (
    <div id="emergency" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-base text-red-600 font-semibold tracking-wide uppercase"
          >
            Emergency Services
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl"
          >
            Help is just a tap away
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-4 max-w-2xl mx-auto text-xl text-gray-500"
          >
            Quick and reliable emergency assistance whenever you need it
          </motion.p>
        </div>

        <div className="mt-20">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
            {emergencyServices.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 + 0.5 }}
                className="relative group"
              >
                <div className="relative bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
                  <div className={`absolute -top-4 left-6 ${service.color} rounded-xl p-3 shadow-md group-hover:scale-110 transition-transform duration-300`}>
                    <service.icon className="h-6 w-6" />
                  </div>
                  <div className="pt-4">
                    <h3 className="mt-4 text-xl font-bold text-gray-900">{service.title}</h3>
                    <p className="mt-4 text-base text-gray-500">{service.description}</p>
                  </div>
                  <button className="mt-6 w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                    Request Help
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="mt-16 text-center"
        >
          <a
            href="tel:112"
            className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-red-600 hover:bg-red-700 transition-colors"
          >
            <Phone className="w-5 h-5 mr-2" />
            Emergency Hotline
          </a>
        </motion.div>
      </div>
    </div>
  );
};

export default Emergency;