import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Shield, CreditCard, Smartphone } from 'lucide-react';

const features = [
  {
    name: '24/7 Availability',
    description: 'Book your parking spot anytime, day or night. Our service never sleeps.',
    icon: Clock,
    color: 'bg-blue-100 text-blue-600',
  },
  {
    name: 'Secure Payments',
    description: 'Your transactions are protected with bank-level security and encryption.',
    icon: Shield,
    color: 'bg-green-100 text-green-600',
  },
  {
    name: 'Instant Booking',
    description: 'Reserve your spot instantly with our real-time booking system.',
    icon: CreditCard,
    color: 'bg-purple-100 text-purple-600',
  },
  {
    name: 'Mobile Access',
    description: 'Manage your reservations on the go with our mobile-friendly platform.',
    icon: Smartphone,
    color: 'bg-orange-100 text-orange-600',
  },
];

const Features = () => {
  return (
    <div className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-base text-blue-600 font-semibold tracking-wide uppercase"
          >
            Features
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl"
          >
            Everything you need to park smarter
          </motion.p>
        </div>

        <div className="mt-20">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, index) => (
              <motion.div
                key={feature.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 + 0.5 }}
                className="relative group"
              >
                <div className="relative bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-shadow duration-300">
                  <div className={`absolute -top-4 left-6 ${feature.color} rounded-xl p-3 shadow-md group-hover:scale-110 transition-transform duration-300`}>
                    <feature.icon className="h-6 w-6" />
                  </div>
                  <div className="pt-4">
                    <h3 className="mt-4 text-xl font-bold text-gray-900">{feature.name}</h3>
                    <p className="mt-4 text-base text-gray-500">{feature.description}</p>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-blue-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Features;