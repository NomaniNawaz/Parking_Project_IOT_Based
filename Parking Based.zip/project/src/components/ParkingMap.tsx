import React, { useState, useEffect, useRef } from 'react';
import { Search, Sliders, MapPin } from 'lucide-react';
import toast from 'react-hot-toast';

// Sample parking data for offline mode
const SAMPLE_PARKING_SPOTS = [
  { id: 1, name: "Central Parking", latitude: 40.7128, longitude: -74.0060, price: "₹50/hour", available: 15 },
  { id: 2, name: "City Plaza Parking", latitude: 40.7200, longitude: -73.9950, price: "₹40/hour", available: 8 },
  { id: 3, name: "Downtown Garage", latitude: 40.7150, longitude: -74.0020, price: "₹60/hour", available: 25 },
  { id: 4, name: "Tech Hub Parking", latitude: 40.7300, longitude: -73.9900, price: "₹45/hour", available: 12 },
  { id: 5, name: "Station Parking", latitude: 40.7180, longitude: -74.0080, price: "₹55/hour", available: 20 },
];

const ParkingMap = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchRadius, setSearchRadius] = useState(2);
  const [selectedSpot, setSelectedSpot] = useState(null);
  const [filteredSpots, setFilteredSpots] = useState(SAMPLE_PARKING_SPOTS);

  const handleSearch = () => {
    if (!searchQuery) {
      setFilteredSpots(SAMPLE_PARKING_SPOTS);
      return;
    }

    const filtered = SAMPLE_PARKING_SPOTS.filter(spot =>
      spot.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredSpots(filtered);
    toast.success(`Found ${filtered.length} parking spots`);
  };

  const handleSpotClick = (spot) => {
    setSelectedSpot(spot);
    toast.success(`Selected: ${spot.name}`);
  };

  return (
    <div className="relative h-[calc(100vh-4rem)]">
      {/* Search Panel */}
      <div className="absolute top-4 left-4 right-4 z-10 bg-white rounded-lg shadow-lg p-4 md:w-96">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">Search Radius</label>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={searchRadius}
                  onChange={(e) => setSearchRadius(parseInt(e.target.value))}
                  className="flex-1"
                />
                <span className="text-sm text-gray-600 min-w-[4rem]">{searchRadius} km</span>
              </div>
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <Sliders className="text-gray-600" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleSearch}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Find Parking
            </button>
            <button
              onClick={() => {
                setSearchQuery('');
                setFilteredSpots(SAMPLE_PARKING_SPOTS);
              }}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Clear
            </button>
          </div>
        </div>
      </div>

      {/* Offline Map View */}
      <div className="w-full h-full bg-gray-100 p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSpots.map((spot) => (
            <div
              key={spot.id}
              onClick={() => handleSpotClick(spot)}
              className={`bg-white p-4 rounded-lg shadow-md cursor-pointer transition-all ${
                selectedSpot?.id === spot.id ? 'ring-2 ring-blue-500' : 'hover:shadow-lg'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{spot.name}</h3>
                  <div className="mt-2 flex items-center text-sm text-gray-500">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>
                      {spot.latitude.toFixed(4)}, {spot.longitude.toFixed(4)}
                    </span>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-sm font-medium ${
                  spot.available > 10
                    ? 'bg-green-100 text-green-800'
                    : spot.available > 0
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {spot.available} spots
                </span>
              </div>
              <div className="mt-4">
                <p className="text-lg font-semibold text-blue-600">{spot.price}</p>
              </div>
              <button className="mt-4 w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Book Now
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 right-4 bg-white p-4 rounded-lg shadow-lg">
        <h4 className="text-sm font-semibold text-gray-900 mb-2">Map Legend</h4>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-500 rounded-full" />
            <span className="text-sm text-gray-600">Many spots available</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-yellow-500 rounded-full" />
            <span className="text-sm text-gray-600">Limited spots</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-500 rounded-full" />
            <span className="text-sm text-gray-600">Full</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ParkingMap;