import { z } from 'zod';

export const parkingSpaceSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1, 'Name is required'),
  location: z.object({
    latitude: z.number(),
    longitude: z.number(),
    address: z.string()
  }),
  pricePerHour: z.number().positive('Price must be positive'),
  totalSpots: z.number().int().positive('Total spots must be positive'),
  availableSpots: z.number().int().min(0, 'Available spots cannot be negative'),
  features: z.array(z.string()),
  status: z.enum(['active', 'inactive', 'maintenance'])
});

export const bookingSchema = z.object({
  spaceId: z.string().uuid(),
  startTime: z.date(),
  endTime: z.date(),
  totalPrice: z.number().positive()
});

export type ParkingSpace = z.infer<typeof parkingSpaceSchema>;
export type Booking = z.infer<typeof bookingSchema>;