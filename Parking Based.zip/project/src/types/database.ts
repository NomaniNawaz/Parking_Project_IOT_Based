export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: 'Admin' | 'Customer' | 'Service Provider';
  status: 'Active' | 'Inactive';
  last_login: string | null;
  created_at: string;
  updated_at: string;
}

export interface NewAdminUser {
  name: string;
  email: string;
  role: AdminUser['role'];
  status: AdminUser['status'];
}