export interface PaymentDetails {
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  name?: string;
}

export interface PaymentResult {
  success: boolean;
  paymentId?: string;
  error?: string;
  timestamp: number;
}

export interface TransactionHistory {
  id: string;
  amount: number;
  currency: string;
  status: 'completed' | 'pending' | 'failed' | 'refunded';
  paymentMethod: string;
  timestamp: number;
}

export interface PaymentError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}