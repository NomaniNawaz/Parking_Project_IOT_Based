import { supabase } from './supabase';
import { ParkingSpace, Booking } from '../types/parking';
import { logUserActivity } from './activity';
import toast from 'react-hot-toast';

export const getParkingSpaces = async (
  filters?: {
    latitude?: number;
    longitude?: number;
    radius?: number;
    minPrice?: number;
    maxPrice?: number;
  }
): Promise<ParkingSpace[]> => {
  try {
    let query = supabase
      .from('parking_spaces')
      .select('*')
      .eq('status', 'active');

    if (filters?.minPrice) {
      query = query.gte('price_per_hour', filters.minPrice);
    }
    if (filters?.maxPrice) {
      query = query.lte('price_per_hour', filters.maxPrice);
    }

    const { data, error } = await query;
    if (error) throw error;

    // Filter by distance if coordinates and radius are provided
    if (filters?.latitude && filters?.longitude && filters?.radius) {
      return data.filter(space => {
        const distance = calculateDistance(
          filters.latitude!,
          filters.longitude!,
          space.location.latitude,
          space.location.longitude
        );
        return distance <= filters.radius!;
      });
    }

    return data;
  } catch (error) {
    console.error('Failed to fetch parking spaces:', error);
    throw error;
  }
};

export const createBooking = async (
  userId: string,
  booking: Omit<Booking, 'id'>
): Promise<string> => {
  try {
    // Check space availability
    const { data: space, error: spaceError } = await supabase
      .from('parking_spaces')
      .select('available_spots, price_per_hour')
      .eq('id', booking.spaceId)
      .single();

    if (spaceError || !space) {
      throw new Error('Parking space not found');
    }

    if (space.available_spots === 0) {
      throw new Error('No available spots');
    }

    // Calculate total price
    const hours = Math.ceil(
      (booking.endTime.getTime() - booking.startTime.getTime()) / (1000 * 60 * 60)
    );
    const totalPrice = hours * space.price_per_hour;

    // Create booking
    const { data, error } = await supabase
      .from('bookings')
      .insert([
        {
          user_id: userId,
          space_id: booking.spaceId,
          start_time: booking.startTime,
          end_time: booking.endTime,
          total_price: totalPrice
        }
      ])
      .select()
      .single();

    if (error) throw error;

    // Log activity
    await logUserActivity(userId, {
      type: 'booking_created',
      details: {
        booking_id: data.id,
        space_id: booking.spaceId,
        total_price: totalPrice
      }
    });

    return data.id;
  } catch (error) {
    console.error('Failed to create booking:', error);
    throw error;
  }
};

export const getUserBookings = async (userId: string): Promise<any[]> => {
  try {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        parking_spaces (
          name,
          location,
          price_per_hour
        )
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Failed to fetch user bookings:', error);
    throw error;
  }
};

export const cancelBooking = async (userId: string, bookingId: string): Promise<void> => {
  try {
    const { error } = await supabase
      .from('bookings')
      .update({ status: 'cancelled' })
      .match({ id: bookingId, user_id: userId });

    if (error) throw error;

    await logUserActivity(userId, {
      type: 'booking_cancelled',
      details: { booking_id: bookingId }
    });

    toast.success('Booking cancelled successfully');
  } catch (error) {
    console.error('Failed to cancel booking:', error);
    throw error;
  }
};

// Helper function to calculate distance between two points using Haversine formula
const calculateDistance = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371; // Earth's radius in km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

const toRad = (value: number): number => {
  return (value * Math.PI) / 180;
};