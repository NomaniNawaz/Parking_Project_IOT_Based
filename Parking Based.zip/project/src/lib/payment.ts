import { PaymentDetails, PaymentResult, PaymentError } from '../types/payment';

export class PaymentProcessor {
  private static instance: PaymentProcessor;
  private constructor() {}

  public static getInstance(): PaymentProcessor {
    if (!PaymentProcessor.instance) {
      PaymentProcessor.instance = new PaymentProcessor();
    }
    return PaymentProcessor.instance;
  }

  public async processPayment(
    amount: number,
    currency: string,
    paymentDetails: PaymentDetails
  ): Promise<PaymentResult> {
    try {
      // Validate payment details
      this.validatePaymentDetails(paymentDetails);

      // Process payment through payment gateway
      const result = await this.processPaymentGateway(amount, currency, paymentDetails);

      return {
        success: true,
        paymentId: result.paymentId,
        timestamp: Date.now()
      };
    } catch (error) {
      const paymentError = error as PaymentError;
      return {
        success: false,
        error: paymentError.message,
        timestamp: Date.now()
      };
    }
  }

  private validatePaymentDetails(details: PaymentDetails): void {
    if (!this.isValidCardNumber(details.cardNumber)) {
      throw this.createError('INVALID_CARD', 'Invalid card number');
    }

    if (!this.isValidExpiryDate(details.expiryDate)) {
      throw this.createError('INVALID_EXPIRY', 'Invalid expiry date');
    }

    if (!this.isValidCVV(details.cvv)) {
      throw this.createError('INVALID_CVV', 'Invalid CVV');
    }
  }

  private isValidCardNumber(cardNumber: string): boolean {
    // Implement Luhn algorithm for card validation
    return cardNumber.length === 16 && /^\d+$/.test(cardNumber);
  }

  private isValidExpiryDate(expiry: string): boolean {
    const [month, year] = expiry.split('/');
    const now = new Date();
    const expiryDate = new Date(2000 + parseInt(year), parseInt(month) - 1);
    return expiryDate > now;
  }

  private isValidCVV(cvv: string): boolean {
    return /^\d{3,4}$/.test(cvv);
  }

  private async processPaymentGateway(
    amount: number,
    currency: string,
    details: PaymentDetails
  ): Promise<{ paymentId: string }> {
    // Simulate payment gateway processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    if (Math.random() > 0.9) {
      throw this.createError('PAYMENT_FAILED', 'Payment processing failed');
    }

    return {
      paymentId: `pay_${Math.random().toString(36).substr(2, 9)}`
    };
  }

  private createError(code: string, message: string): PaymentError {
    return {
      code,
      message,
      details: {
        timestamp: Date.now()
      }
    };
  }

  public async refundPayment(paymentId: string): Promise<PaymentResult> {
    try {
      // Simulate refund processing
      await new Promise(resolve => setTimeout(resolve, 1500));

      return {
        success: true,
        paymentId,
        timestamp: Date.now()
      };
    } catch (error) {
      const paymentError = error as PaymentError;
      return {
        success: false,
        error: paymentError.message,
        timestamp: Date.now()
      };
    }
  }
}