import OpenAI from 'openai';

const getOpenAIInstance = () => {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (!apiKey || apiKey === 'your-openai-api-key') {
    console.warn('OpenAI API key is not configured. Chat features will be disabled.');
    return null;
  }

  return new OpenAI({
    apiKey,
    dangerouslyAllowBrowser: true
  });
};

let openai: OpenAI | null;
try {
  openai = getOpenAIInstance();
} catch (error) {
  console.error('Failed to initialize OpenAI client:', error);
  openai = null;
}

export const generateResponse = async (
  messages: { role: 'user' | 'assistant'; content: string }[]
): Promise<string> => {
  if (!openai) {
    return 'The AI chat feature is currently disabled. Please configure your OpenAI API key to enable this feature.';
  }

  try {
    const completion = await openai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a helpful parking assistant that helps users find and book parking spots.'
        },
        ...messages
      ],
      model: 'gpt-3.5-turbo',
    });

    return completion.choices[0].message.content || 'I apologize, but I could not generate a response.';
  } catch (error) {
    console.error('Error generating AI response:', error);
    return 'Sorry, I encountered an error while generating a response. Please try again later.';
  }
};