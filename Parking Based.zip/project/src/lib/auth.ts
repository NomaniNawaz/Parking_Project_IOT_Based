import { supabase } from './supabase';
import { SignUpFormData, SignInFormData, AuthResponse } from '../types/auth';
import toast from 'react-hot-toast';

export const signUp = async (data: SignUpFormData): Promise<AuthResponse> => {
  try {
    // First check if email already exists
    const { data: existingUser } = await supabase
      .from('profiles')
      .select('email')
      .eq('email', data.email)
      .single();

    if (existingUser) {
      throw new Error('Email already registered');
    }

    // Create auth user
    const { data: authData, error: signUpError } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: {
        data: {
          full_name: data.fullName,
        },
      },
    });

    if (signUpError) throw signUpError;

    if (!authData.user) {
      throw new Error('Failed to create user');
    }

    // Create profile
    const { error: profileError } = await supabase
      .from('profiles')
      .insert([
        {
          id: authData.user.id,
          full_name: data.fullName,
          email: data.email,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ]);

    if (profileError) throw profileError;

    toast.success('Account created successfully! Please sign in to continue.');
    return { data: authData, error: null };
  } catch (error: any) {
    console.error('Signup error:', error);
    const errorMessage = error.message === 'Email already registered' 
      ? 'This email is already registered. Please sign in instead.'
      : 'Failed to create account. Please try again.';
    toast.error(errorMessage);
    return { data: { user: null, session: null }, error };
  }
};

export const signIn = async (data: SignInFormData): Promise<AuthResponse> => {
  try {
    // First verify if the user exists in profiles
    const { data: existingProfile } = await supabase
      .from('profiles')
      .select('email')
      .eq('email', data.email)
      .single();

    if (!existingProfile) {
      throw new Error('No account found with this email. Please sign up first.');
    }

    // Attempt to sign in
    const { data: authData, error: signInError } = await supabase.auth.signInWithPassword({
      email: data.email,
      password: data.password,
    });

    if (signInError) {
      if (signInError.message === 'Invalid login credentials') {
        throw new Error('Incorrect email or password. Please try again.');
      }
      throw signInError;
    }

    if (!authData.user) {
      throw new Error('Login failed. Please try again.');
    }

    // Check if user is admin
    const { data: adminUser } = await supabase
      .from('admin_users')
      .select('role')
      .eq('email', data.email)
      .single();

    const isAdmin = adminUser?.role === 'Admin';
    if (isAdmin) {
      localStorage.setItem('isAdmin', 'true');
      toast.success('Welcome back, Admin!');
      return { 
        data: authData, 
        error: null,
        isAdmin: true 
      };
    }

    // Regular user login flow
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', authData.user.id)
      .single();

    if (profileError || !profile) {
      const { data: userData } = await supabase.auth.getUser();
      const userMetadata = userData?.user?.user_metadata;
      
      const defaultProfile = {
        id: authData.user.id,
        full_name: userMetadata?.full_name || authData.user.email?.split('@')[0] || 'User',
        email: authData.user.email,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        last_login: new Date().toISOString(),
        preferences: {
          theme: 'light',
          newsletter: true,
          notifications: true
        }
      };

      const { error: createError } = await supabase
        .from('profiles')
        .insert([defaultProfile]);

      if (createError) {
        throw new Error('Failed to create user profile. Please try again.');
      }

      toast.success(`Welcome, ${defaultProfile.full_name}!`);
      return {
        data: authData,
        error: null,
        isAdmin: false
      };
    }

    // Update last login
    await supabase
      .from('profiles')
      .update({ 
        last_login: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', authData.user.id);

    toast.success(`Welcome back, ${profile.full_name}!`);
    return { 
      data: authData, 
      error: null,
      isAdmin: false 
    };
  } catch (error: any) {
    console.error('Login error:', error);
    const errorMessage = error.message === 'No account found with this email. Please sign up first.'
      ? error.message
      : error.message === 'Incorrect email or password. Please try again.'
        ? error.message
        : 'Failed to sign in. Please try again.';
    toast.error(errorMessage);
    return { 
      data: { user: null, session: null }, 
      error,
      isAdmin: false 
    };
  }
};

export const signOut = async (): Promise<void> => {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    localStorage.removeItem('isAdmin');
    toast.success('Signed out successfully');
  } catch (error: any) {
    console.error('Signout error:', error);
    toast.error(error.message || 'Failed to sign out');
  }
};

export const getCurrentUser = async () => {
  try {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error) throw error;
    
    if (!user) return null;

    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    return profile;
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};