import { supabase } from './supabase';
import { logUserActivity } from './activity';
import toast from 'react-hot-toast';

// Types
interface AdminStats {
  totalUsers: number;
  activeBookings: number;
  serviceProviders: number;
  emergencyRequests: number;
  revenue: {
    daily: number;
    weekly: number;
    monthly: number;
  };
}

interface UserManagementStats {
  totalUsers: number;
  activeUsers: number;
  newUsersToday: number;
  userGrowthRate: number;
}

interface BookingManagementStats {
  totalBookings: number;
  activeBookings: number;
  completedBookings: number;
  cancelledBookings: number;
  averageBookingDuration: number;
}

interface RevenueStats {
  totalRevenue: number;
  dailyRevenue: number;
  weeklyRevenue: number;
  monthlyRevenue: number;
  averageTransactionValue: number;
}

interface ServiceProviderStats {
  totalProviders: number;
  activeProviders: number;
  averageRating: number;
  topPerformers: Array<{
    id: string;
    name: string;
    completedJobs: number;
    rating: number;
  }>;
}

interface EmergencyStats {
  totalRequests: number;
  pendingRequests: number;
  averageResponseTime: number;
  resolutionRate: number;
}

// Admin Service Class
class AdminService {
  private static instance: AdminService;

  private constructor() {}

  public static getInstance(): AdminService {
    if (!AdminService.instance) {
      AdminService.instance = new AdminService();
    }
    return AdminService.instance;
  }

  // User Management
  async getUsers(
    page = 1,
    limit = 10,
    filters?: {
      status?: string;
      role?: string;
      search?: string;
    }
  ) {
    try {
      let query = supabase
        .from('profiles')
        .select('*', { count: 'exact' });

      if (filters?.status) {
        query = query.eq('status', filters.status);
      }
      if (filters?.role) {
        query = query.eq('role', filters.role);
      }
      if (filters?.search) {
        query = query.or(`full_name.ilike.%${filters.search}%,email.ilike.%${filters.search}%`);
      }

      const { data, error, count } = await query
        .range((page - 1) * limit, page * limit - 1)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return {
        users: data || [],
        total: count || 0,
        page,
        limit
      };
    } catch (error) {
      console.error('Error fetching users:', error);
      throw error;
    }
  }

  async updateUserStatus(userId: string, status: string) {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ status })
        .eq('id', userId);

      if (error) throw error;

      toast.success('User status updated successfully');
    } catch (error) {
      console.error('Error updating user status:', error);
      throw error;
    }
  }

  async getUserManagementStats(): Promise<UserManagementStats> {
    try {
      const [
        { count: totalUsers },
        { count: activeUsers },
        { count: newUsers }
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact' }),
        supabase.from('profiles').select('*', { count: 'exact' })
          .eq('status', 'active'),
        supabase.from('profiles').select('*', { count: 'exact' })
          .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
      ]);

      // Calculate growth rate
      const { count: lastWeekUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact' })
        .lt('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString());

      const growthRate = lastWeekUsers ? ((totalUsers - lastWeekUsers) / lastWeekUsers) * 100 : 0;

      return {
        totalUsers: totalUsers || 0,
        activeUsers: activeUsers || 0,
        newUsersToday: newUsers || 0,
        userGrowthRate: growthRate
      };
    } catch (error) {
      console.error('Error fetching user management stats:', error);
      throw error;
    }
  }

  // Booking Management
  async getBookings(
    page = 1,
    limit = 10,
    filters?: {
      status?: string;
      startDate?: Date;
      endDate?: Date;
      search?: string;
    }
  ) {
    try {
      let query = supabase
        .from('slot_bookings')
        .select(`
          *,
          profiles (full_name, email),
          parking_slots (
            slot_number,
            parking_zones (name)
          )
        `, { count: 'exact' });

      if (filters?.status) {
        query = query.eq('status', filters.status);
      }
      if (filters?.startDate) {
        query = query.gte('start_time', filters.startDate.toISOString());
      }
      if (filters?.endDate) {
        query = query.lte('end_time', filters.endDate.toISOString());
      }

      const { data, error, count } = await query
        .range((page - 1) * limit, page * limit - 1)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return {
        bookings: data || [],
        total: count || 0,
        page,
        limit
      };
    } catch (error) {
      console.error('Error fetching bookings:', error);
      throw error;
    }
  }

  async getBookingManagementStats(): Promise<BookingManagementStats> {
    try {
      const [
        { count: totalBookings },
        { count: activeBookings },
        { count: completedBookings },
        { count: cancelledBookings },
        { data: durationData }
      ] = await Promise.all([
        supabase.from('slot_bookings').select('*', { count: 'exact' }),
        supabase.from('slot_bookings').select('*', { count: 'exact' })
          .eq('status', 'active'),
        supabase.from('slot_bookings').select('*', { count: 'exact' })
          .eq('status', 'completed'),
        supabase.from('slot_bookings').select('*', { count: 'exact' })
          .eq('status', 'cancelled'),
        supabase.from('slot_bookings').select('start_time, end_time')
          .eq('status', 'completed')
      ]);

      // Calculate average duration
      const averageDuration = durationData?.reduce((acc, booking) => {
        const duration = new Date(booking.end_time).getTime() - new Date(booking.start_time).getTime();
        return acc + duration;
      }, 0) / (durationData?.length || 1);

      return {
        totalBookings: totalBookings || 0,
        activeBookings: activeBookings || 0,
        completedBookings: completedBookings || 0,
        cancelledBookings: cancelledBookings || 0,
        averageBookingDuration: averageDuration / (1000 * 60 * 60) // Convert to hours
      };
    } catch (error) {
      console.error('Error fetching booking management stats:', error);
      throw error;
    }
  }

  // Revenue Management
  async getRevenueStats(): Promise<RevenueStats> {
    try {
      const now = new Date();
      const dayStart = new Date(now.setHours(0, 0, 0, 0));
      const weekStart = new Date(now.setDate(now.getDate() - 7));
      const monthStart = new Date(now.setDate(1));

      const [
        { data: totalData },
        { data: dailyData },
        { data: weeklyData },
        { data: monthlyData }
      ] = await Promise.all([
        supabase.from('payment_transactions').select('amount')
          .eq('status', 'completed'),
        supabase.from('payment_transactions').select('amount')
          .eq('status', 'completed')
          .gte('created_at', dayStart.toISOString()),
        supabase.from('payment_transactions').select('amount')
          .eq('status', 'completed')
          .gte('created_at', weekStart.toISOString()),
        supabase.from('payment_transactions').select('amount')
          .eq('status', 'completed')
          .gte('created_at', monthStart.toISOString())
      ]);

      const calculateTotal = (data: any[]) => 
        data?.reduce((acc, transaction) => acc + transaction.amount, 0) || 0;

      const totalRevenue = calculateTotal(totalData);
      const averageTransaction = totalData?.length ? 
        totalRevenue / totalData.length : 0;

      return {
        totalRevenue,
        dailyRevenue: calculateTotal(dailyData),
        weeklyRevenue: calculateTotal(weeklyData),
        monthlyRevenue: calculateTotal(monthlyData),
        averageTransactionValue: averageTransaction
      };
    } catch (error) {
      console.error('Error fetching revenue stats:', error);
      throw error;
    }
  }

  // Service Provider Management
  async getServiceProviders(
    page = 1,
    limit = 10,
    filters?: {
      type?: string;
      status?: string;
      search?: string;
    }
  ) {
    try {
      let query = supabase
        .from('service_providers')
        .select('*', { count: 'exact' });

      if (filters?.type) {
        query = query.eq('type', filters.type);
      }
      if (filters?.status) {
        query = query.eq('status', filters.status);
      }
      if (filters?.search) {
        query = query.or(`name.ilike.%${filters.search}%,specialization.ilike.%${filters.search}%`);
      }

      const { data, error, count } = await query
        .range((page - 1) * limit, page * limit - 1)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return {
        providers: data || [],
        total: count || 0,
        page,
        limit
      };
    } catch (error) {
      console.error('Error fetching service providers:', error);
      throw error;
    }
  }

  async getServiceProviderStats(): Promise<ServiceProviderStats> {
    try {
      const [
        { count: totalProviders },
        { count: activeProviders },
        { data: providers }
      ] = await Promise.all([
        supabase.from('service_providers').select('*', { count: 'exact' }),
        supabase.from('service_providers').select('*', { count: 'exact' })
          .eq('status', 'Available'),
        supabase.from('service_providers').select('*')
          .order('completed_jobs', { ascending: false })
          .limit(5)
      ]);

      const averageRating = providers?.reduce((acc, provider) => 
        acc + provider.rating, 0) / (providers?.length || 1);

      return {
        totalProviders: totalProviders || 0,
        activeProviders: activeProviders || 0,
        averageRating,
        topPerformers: providers?.map(provider => ({
          id: provider.id,
          name: provider.name,
          completedJobs: provider.completed_jobs,
          rating: provider.rating
        })) || []
      };
    } catch (error) {
      console.error('Error fetching service provider stats:', error);
      throw error;
    }
  }

  // Emergency Management
  async getEmergencyRequests(
    page = 1,
    limit = 10,
    filters?: {
      status?: string;
      type?: string;
      search?: string;
    }
  ) {
    try {
      let query = supabase
        .from('emergency_requests')
        .select(`
          *,
          profiles (full_name, email),
          service_providers (name)
        `, { count: 'exact' });

      if (filters?.status) {
        query = query.eq('status', filters.status);
      }
      if (filters?.type) {
        query = query.eq('type', filters.type);
      }

      const { data, error, count } = await query
        .range((page - 1) * limit, page * limit - 1)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return {
        requests: data || [],
        total: count || 0,
        page,
        limit
      };
    } catch (error) {
      console.error('Error fetching emergency requests:', error);
      throw error;
    }
  }

  async getEmergencyStats(): Promise<EmergencyStats> {
    try {
      const [
        { count: totalRequests },
        { count: pendingRequests },
        { data: completedRequests }
      ] = await Promise.all([
        supabase.from('emergency_requests').select('*', { count: 'exact' }),
        supabase.from('emergency_requests').select('*', { count: 'exact' })
          .eq('status', 'pending'),
        supabase.from('emergency_requests').select('created_at, updated_at')
          .eq('status', 'completed')
      ]);

      // Calculate average response time and resolution rate
      const averageResponse = completedRequests?.reduce((acc, request) => {
        const responseTime = new Date(request.updated_at).getTime() - new Date(request.created_at).getTime();
        return acc + responseTime;
      }, 0) / (completedRequests?.length || 1);

      const resolutionRate = totalRequests ? 
        (completedRequests?.length || 0) / totalRequests * 100 : 0;

      return {
        totalRequests: totalRequests || 0,
        pendingRequests: pendingRequests || 0,
        averageResponseTime: averageResponse / (1000 * 60), // Convert to minutes
        resolutionRate
      };
    } catch (error) {
      console.error('Error fetching emergency stats:', error);
      throw error;
    }
  }

  // Dashboard Stats
  async getDashboardStats(): Promise<AdminStats> {
    try {
      const [
        userStats,
        bookingStats,
        revenueStats,
        providerStats,
        emergencyStats
      ] = await Promise.all([
        this.getUserManagementStats(),
        this.getBookingManagementStats(),
        this.getRevenueStats(),
        this.getServiceProviderStats(),
        this.getEmergencyStats()
      ]);

      return {
        totalUsers: userStats.totalUsers,
        activeBookings: bookingStats.activeBookings,
        serviceProviders: providerStats.totalProviders,
        emergencyRequests: emergencyStats.pendingRequests,
        revenue: {
          daily: revenueStats.dailyRevenue,
          weekly: revenueStats.weeklyRevenue,
          monthly: revenueStats.monthlyRevenue
        }
      };
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      throw error;
    }
  }

  // Activity Logs
  async getActivityLogs(
    page = 1,
    limit = 10,
    filters?: {
      userId?: string;
      type?: string;
      startDate?: Date;
      endDate?: Date;
    }
  ) {
    try {
      let query = supabase
        .from('user_activity')
        .select(`
          *,
          profiles (full_name, email)
        `, { count: 'exact' });

      if (filters?.userId) {
        query = query.eq('user_id', filters.userId);
      }
      if (filters?.type) {
        query = query.eq('type', filters.type);
      }
      if (filters?.startDate) {
        query = query.gte('created_at', filters.startDate.toISOString());
      }
      if (filters?.endDate) {
        query = query.lte('created_at', filters.endDate.toISOString());
      }

      const { data, error, count } = await query
        .range((page - 1) * limit, page * limit - 1)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return {
        logs: data || [],
        total: count || 0,
        page,
        limit
      };
    } catch (error) {
      console.error('Error fetching activity logs:', error);
      throw error;
    }
  }
}

export const adminService = AdminService.getInstance();