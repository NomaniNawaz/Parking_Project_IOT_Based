import { supabase } from './supabase';
import { logUserActivity } from './activity';
import { PaymentProcessor } from './payment';
import { ParkingSpace, Booking } from '../types/parking';
import toast from 'react-hot-toast';

// Types
interface ParkingZone {
  id: string;
  name: string;
  location: {
    latitude: number;
    longitude: number;
    address: string;
  };
  totalCapacity: number;
  hourlyRate: number;
  features: string[];
  status: string;
}

interface ParkingSlot {
  id: string;
  zoneId: string;
  slotNumber: string;
  type: 'standard' | 'premium';
  status: 'available' | 'occupied' | 'maintenance';
  sensorId?: string;
}

interface SlotBooking {
  id: string;
  userId: string;
  slotId: string;
  startTime: Date;
  endTime: Date;
  amount: number;
  paymentStatus: 'pending' | 'completed' | 'failed';
  qrCode?: string;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
}

// Backend Service Class
class BackendService {
  private static instance: BackendService;
  private paymentProcessor: PaymentProcessor;

  private constructor() {
    this.paymentProcessor = PaymentProcessor.getInstance();
  }

  public static getInstance(): BackendService {
    if (!BackendService.instance) {
      BackendService.instance = new BackendService();
    }
    return BackendService.instance;
  }

  // Parking Zones
  async getParkingZones(): Promise<ParkingZone[]> {
    try {
      const { data, error } = await supabase
        .from('parking_zones')
        .select('*')
        .eq('status', 'active');

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching parking zones:', error);
      throw error;
    }
  }

  async getParkingZoneDetails(zoneId: string): Promise<ParkingZone & { slots: ParkingSlot[] }> {
    try {
      const [{ data: zone }, { data: slots }] = await Promise.all([
        supabase
          .from('parking_zones')
          .select('*')
          .eq('id', zoneId)
          .single(),
        supabase
          .from('parking_slots')
          .select('*')
          .eq('zone_id', zoneId)
      ]);

      if (!zone) throw new Error('Parking zone not found');

      return {
        ...zone,
        slots: slots || []
      };
    } catch (error) {
      console.error('Error fetching zone details:', error);
      throw error;
    }
  }

  // Parking Slots
  async getAvailableSlots(
    zoneId: string,
    startTime: Date,
    endTime: Date
  ): Promise<ParkingSlot[]> {
    try {
      const { data: slots, error } = await supabase.rpc('get_available_slots', {
        p_zone_id: zoneId,
        p_start_time: startTime.toISOString(),
        p_end_time: endTime.toISOString()
      });

      if (error) throw error;
      return slots || [];
    } catch (error) {
      console.error('Error fetching available slots:', error);
      throw error;
    }
  }

  // Bookings
  async createBooking(
    userId: string,
    slotId: string,
    startTime: Date,
    endTime: Date,
    amount: number
  ): Promise<SlotBooking> {
    try {
      // Check slot availability
      const isAvailable = await this.checkSlotAvailability(slotId, startTime, endTime);
      if (!isAvailable) {
        throw new Error('Slot is not available for the selected time period');
      }

      // Create booking
      const { data, error } = await supabase
        .from('slot_bookings')
        .insert([{
          user_id: userId,
          slot_id: slotId,
          start_time: startTime,
          end_time: endTime,
          amount,
          status: 'pending'
        }])
        .select()
        .single();

      if (error) throw error;

      // Log activity
      await logUserActivity(userId, {
        type: 'booking_created',
        details: {
          booking_id: data.id,
          slot_id: slotId,
          amount
        }
      });

      return data;
    } catch (error) {
      console.error('Error creating booking:', error);
      throw error;
    }
  }

  async getUserBookings(userId: string): Promise<SlotBooking[]> {
    try {
      const { data, error } = await supabase
        .from('slot_bookings')
        .select(`
          *,
          parking_slots (
            *,
            parking_zones (*)
          )
        `)
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching user bookings:', error);
      throw error;
    }
  }

  async cancelBooking(userId: string, bookingId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('slot_bookings')
        .update({ status: 'cancelled' })
        .match({ id: bookingId, user_id: userId });

      if (error) throw error;

      await logUserActivity(userId, {
        type: 'booking_cancelled',
        details: { booking_id: bookingId }
      });

      toast.success('Booking cancelled successfully');
    } catch (error) {
      console.error('Error cancelling booking:', error);
      throw error;
    }
  }

  // Payments
  async processPayment(
    userId: string,
    bookingId: string,
    amount: number,
    paymentMethod: string
  ): Promise<void> {
    try {
      // Create payment transaction
      const { data: transaction, error: transactionError } = await supabase
        .from('payment_transactions')
        .insert([{
          booking_id: bookingId,
          amount,
          payment_method: paymentMethod,
          status: 'pending'
        }])
        .select()
        .single();

      if (transactionError) throw transactionError;

      // Process payment
      const result = await this.paymentProcessor.processPayment(
        amount,
        'USD',
        {
          cardNumber: '4242424242424242', // Test card
          expiryDate: '12/25',
          cvv: '123'
        }
      );

      if (!result.success) {
        throw new Error(result.error);
      }

      // Update transaction and booking
      const [{ error: updateError }, { error: bookingError }] = await Promise.all([
        supabase
          .from('payment_transactions')
          .update({
            status: 'completed',
            transaction_id: result.paymentId
          })
          .eq('id', transaction.id),
        supabase
          .from('slot_bookings')
          .update({
            payment_status: 'completed',
            status: 'active'
          })
          .eq('id', bookingId)
      ]);

      if (updateError) throw updateError;
      if (bookingError) throw bookingError;

      await logUserActivity(userId, {
        type: 'payment_completed',
        details: {
          booking_id: bookingId,
          transaction_id: result.paymentId,
          amount
        }
      });

      toast.success('Payment processed successfully');
    } catch (error) {
      console.error('Error processing payment:', error);
      throw error;
    }
  }

  // Utility Functions
  private async checkSlotAvailability(
    slotId: string,
    startTime: Date,
    endTime: Date
  ): Promise<boolean> {
    try {
      const { data, error } = await supabase.rpc('check_slot_availability', {
        p_slot_id: slotId,
        p_start_time: startTime.toISOString(),
        p_end_time: endTime.toISOString()
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error checking slot availability:', error);
      throw error;
    }
  }

  // Emergency Services
  async requestEmergencyService(
    userId: string,
    type: string,
    location: string,
    description?: string
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('emergency_requests')
        .insert([{
          user_id: userId,
          type,
          location,
          description,
          status: 'pending'
        }]);

      if (error) throw error;

      await logUserActivity(userId, {
        type: 'emergency_requested',
        details: { type, location }
      });

      toast.success('Emergency service requested successfully');
    } catch (error) {
      console.error('Error requesting emergency service:', error);
      throw error;
    }
  }

  async getEmergencyRequests(userId: string): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('emergency_requests')
        .select(`
          *,
          service_providers (*)
        `)
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching emergency requests:', error);
      throw error;
    }
  }

  // Service Providers
  async getServiceProviders(type?: string): Promise<any[]> {
    try {
      let query = supabase
        .from('service_providers')
        .select('*')
        .eq('status', 'Available');

      if (type) {
        query = query.eq('type', type);
      }

      const { data, error } = await query;

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching service providers:', error);
      throw error;
    }
  }

  // Admin Functions
  async getAdminStats(): Promise<any> {
    try {
      const [
        { count: usersCount },
        { count: bookingsCount },
        { count: providersCount },
        { count: emergencyCount }
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact' }),
        supabase.from('slot_bookings').select('*', { count: 'exact' }).eq('status', 'active'),
        supabase.from('service_providers').select('*', { count: 'exact' }),
        supabase.from('emergency_requests').select('*', { count: 'exact' }).eq('status', 'pending')
      ]);

      return {
        totalUsers: usersCount || 0,
        activeBookings: bookingsCount || 0,
        serviceProviders: providersCount || 0,
        emergencyRequests: emergencyCount || 0
      };
    } catch (error) {
      console.error('Error fetching admin stats:', error);
      throw error;
    }
  }
}

export const backend = BackendService.getInstance();