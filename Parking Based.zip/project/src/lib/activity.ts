import { supabase } from './supabase';

export interface ActivityLog {
  type: string;
  details?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
}

export const logUserActivity = async (
  userId: string,
  activity: ActivityLog
): Promise<void> => {
  try {
    const { error } = await supabase.rpc('log_user_activity', {
      p_user_id: userId,
      p_type: activity.type,
      p_details: activity.details || {},
      p_ip_address: activity.ipAddress,
      p_user_agent: activity.userAgent
    });

    if (error) throw error;
  } catch (error) {
    console.error('Failed to log user activity:', error);
    // Don't throw error to prevent disrupting the user experience
  }
};

export const getUserActivity = async (
  userId: string,
  limit = 10
): Promise<any[]> => {
  try {
    const { data, error } = await supabase
      .from('user_activity')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Failed to fetch user activity:', error);
    return [];
  }
};