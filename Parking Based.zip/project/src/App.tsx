import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, RequireAuth } from './components/auth/AuthProvider';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import QuoteCarousel from './components/QuoteCarousel';
import ParkingMap from './components/ParkingMap';
import ParkingInfo from './components/ParkingInfo';
import HowItWorks from './components/HowItWorks';
import Emergency from './components/Emergency';
import Pricing from './components/Pricing';
import Chatbot from './components/Chatbot';
import SignIn from './components/auth/SignIn';
import SignUp from './components/auth/SignUp';
import Dashboard from './components/dashboard/Dashboard';
import RegisterParking from './components/parking/RegisterParking';
import FindParking from './components/parking/FindParking';
import AdminDashboard from './components/admin/AdminDashboard';
import AdminRoute from './components/auth/AdminRoute';
import PaymentSystem from './components/payment/PaymentSystem';

function App() {
  return (
    <Router>
      <AuthProvider>
        <div className="min-h-screen bg-gray-50">
          <Toaster position="top-right" />
          <Routes>
            {/* Public routes */}
            <Route path="/signin" element={<SignIn />} />
            <Route path="/signup" element={<SignUp />} />
            
            {/* Protected routes */}
            <Route path="/dashboard" element={
              <RequireAuth>
                <Navbar />
                <Dashboard />
              </RequireAuth>
            } />
            
            <Route path="/register-parking" element={
              <RequireAuth>
                <Navbar />
                <RegisterParking />
              </RequireAuth>
            } />
            
            <Route path="/find-parking" element={
              <RequireAuth>
                <Navbar />
                <FindParking />
              </RequireAuth>
            } />
            
            <Route path="/payment" element={
              <RequireAuth>
                <Navbar />
                <PaymentSystem amount={50} currency="USD" />
              </RequireAuth>
            } />
            
            <Route path="/admin/*" element={
              <AdminRoute>
                <AdminDashboard />
              </AdminRoute>
            } />
            
            {/* Landing page */}
            <Route path="/" element={
              <>
                <Navbar />
                <main>
                  <Hero />
                  <Features />
                  <QuoteCarousel />
                  <HowItWorks />
                  <ParkingInfo />
                  <Emergency />
                  <Pricing />
                  <Chatbot />
                </main>
              </>
            } />
          </Routes>
        </div>
      </AuthProvider>
    </Router>
  );
}

export default App;