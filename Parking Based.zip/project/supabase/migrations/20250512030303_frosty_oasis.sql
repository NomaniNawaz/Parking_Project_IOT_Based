-- Create admin user with proper authentication
DO $$
DECLARE
  v_user_id uuid;
BEGIN
  -- First ensure the admin user exists in auth.users
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE email = 'admin@parkease.com'
  ) THEN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      confirmation_token,
      recovery_token,
      email_change_token_new,
      email_change,
      last_sign_in_at
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'admin@parkease.com',
      crypt('admin123', gen_salt('bf')), -- Set password to 'admin123'
      now(),
      now(),
      now(),
      '',
      '',
      '',
      '',
      now()
    )
    RETURNING id INTO v_user_id;

    -- Create profile for admin
    INSERT INTO profiles (
      id,
      full_name,
      email,
      created_at,
      updated_at
    ) VALUES (
      v_user_id,
      'Admin User',
      'admin@parkease.com',
      now(),
      now()
    );
  END IF;

  -- Ensure admin exists in admin_users
  IF NOT EXISTS (
    SELECT 1 FROM admin_users WHERE email = 'admin@parkease.com'
  ) THEN
    INSERT INTO admin_users (
      name,
      email,
      role,
      status,
      created_at,
      updated_at
    ) VALUES (
      'Admin User',
      'admin@parkease.com',
      'Admin',
      'Active',
      now(),
      now()
    );
  END IF;
END $$;