/*
  # Add notifications system

  1. New Tables
    - `notifications`
      - `id` (uuid, primary key)
      - `type` (text)
      - `title` (text)
      - `message` (text)
      - `read` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `notifications` table
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read notifications
CREATE POLICY "Enable read access for authenticated users"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow admin users to manage notifications
CREATE POLICY "Enable admin operations for admins"
  ON notifications
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM auth.users u 
      WHERE u.email = current_user 
      AND u.email = 'admin@parkease.com'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 
      FROM auth.users u 
      WHERE u.email = current_user 
      AND u.email = 'admin@parkease.com'
    )
  );

-- Add some sample notifications
INSERT INTO notifications (type, title, message, created_at) VALUES
('emergency', 'New Emergency Request', 'User John Doe requires immediate assistance at Downtown Parking', now() - interval '2 minutes'),
('booking', 'New Parking Booking', 'Booking #12345 confirmed for Central Plaza Parking', now() - interval '5 minutes'),
('system', 'System Update', 'New system update available. Please review and install.', now() - interval '1 hour');