/*
  # Create Smart Parking System Core Schema

  1. New Tables
    - `parking_zones`
      - `id` (uuid, primary key)
      - `name` (text)
      - `location` (jsonb)
      - `total_capacity` (integer)
      - `hourly_rate` (numeric)
      - `features` (jsonb)
      - `status` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `parking_slots`
      - `id` (uuid, primary key)
      - `zone_id` (uuid, references parking_zones)
      - `slot_number` (text)
      - `type` (text)
      - `status` (text)
      - `sensor_id` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `slot_bookings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `slot_id` (uuid, references parking_slots)
      - `start_time` (timestamptz)
      - `end_time` (timestamptz)
      - `amount` (numeric)
      - `payment_status` (text)
      - `qr_code` (text)
      - `status` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `payment_transactions`
      - `id` (uuid, primary key)
      - `booking_id` (uuid, references slot_bookings)
      - `amount` (numeric)
      - `currency` (text)
      - `payment_method` (text)
      - `status` (text)
      - `transaction_id` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Add admin-specific policies
*/

-- Create parking_zones table
CREATE TABLE IF NOT EXISTS parking_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location jsonb NOT NULL,
  total_capacity integer NOT NULL CHECK (total_capacity > 0),
  hourly_rate numeric NOT NULL CHECK (hourly_rate >= 0),
  features jsonb DEFAULT '[]',
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create parking_slots table
CREATE TABLE IF NOT EXISTS parking_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id uuid REFERENCES parking_zones ON DELETE CASCADE,
  slot_number text NOT NULL,
  type text NOT NULL DEFAULT 'standard',
  status text NOT NULL DEFAULT 'available',
  sensor_id text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(zone_id, slot_number)
);

-- Create slot_bookings table
CREATE TABLE IF NOT EXISTS slot_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles ON DELETE CASCADE,
  slot_id uuid REFERENCES parking_slots ON DELETE CASCADE,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  amount numeric NOT NULL CHECK (amount >= 0),
  payment_status text NOT NULL DEFAULT 'pending',
  qr_code text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_booking_time CHECK (end_time > start_time)
);

-- Create payment_transactions table
CREATE TABLE IF NOT EXISTS payment_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES slot_bookings ON DELETE CASCADE,
  amount numeric NOT NULL CHECK (amount >= 0),
  currency text NOT NULL DEFAULT 'USD',
  payment_method text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  transaction_id text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE parking_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE parking_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE slot_bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_transactions ENABLE ROW LEVEL SECURITY;

-- Policies for parking_zones
CREATE POLICY "parking_zones_read_policy"
  ON parking_zones
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "parking_zones_admin_policy"
  ON parking_zones
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  );

-- Policies for parking_slots
CREATE POLICY "parking_slots_read_policy"
  ON parking_slots
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "parking_slots_admin_policy"
  ON parking_slots
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  );

-- Policies for slot_bookings
CREATE POLICY "slot_bookings_read_policy"
  ON slot_bookings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "slot_bookings_insert_policy"
  ON slot_bookings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "slot_bookings_update_policy"
  ON slot_bookings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "slot_bookings_admin_policy"
  ON slot_bookings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  );

-- Policies for payment_transactions
CREATE POLICY "payment_transactions_read_policy"
  ON payment_transactions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM slot_bookings sb
      WHERE sb.id = booking_id
      AND sb.user_id = auth.uid()
    )
  );

CREATE POLICY "payment_transactions_insert_policy"
  ON payment_transactions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM slot_bookings sb
      WHERE sb.id = booking_id
      AND sb.user_id = auth.uid()
    )
  );

CREATE POLICY "payment_transactions_admin_policy"
  ON payment_transactions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  );

-- Create functions for slot management
CREATE OR REPLACE FUNCTION check_slot_availability(
  p_slot_id uuid,
  p_start_time timestamptz,
  p_end_time timestamptz
) RETURNS boolean AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM slot_bookings
    WHERE slot_id = p_slot_id
    AND status NOT IN ('cancelled', 'completed')
    AND (
      (start_time <= p_start_time AND end_time > p_start_time)
      OR (start_time < p_end_time AND end_time >= p_end_time)
      OR (start_time >= p_start_time AND end_time <= p_end_time)
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger function to update slot status
CREATE OR REPLACE FUNCTION update_slot_status()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE parking_slots
    SET status = 'occupied'
    WHERE id = NEW.slot_id;
  ELSIF TG_OP = 'UPDATE' AND NEW.status IN ('cancelled', 'completed') THEN
    UPDATE parking_slots
    SET status = 'available'
    WHERE id = OLD.slot_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for slot status updates
CREATE TRIGGER slot_status_update
  AFTER INSERT OR UPDATE ON slot_bookings
  FOR EACH ROW
  EXECUTE FUNCTION update_slot_status();

-- Insert sample parking zones
INSERT INTO parking_zones (name, location, total_capacity, hourly_rate, features) VALUES
(
  'Downtown Parking A',
  '{"latitude": 40.7128, "longitude": -74.0060, "address": "123 Main St, New York, NY"}',
  100,
  15.00,
  '["CCTV", "24/7 Security", "EV Charging"]'
),
(
  'Central Station Parking',
  '{"latitude": 40.7527, "longitude": -73.9772, "address": "456 Park Ave, New York, NY"}',
  150,
  20.00,
  '["Valet Service", "Car Wash", "Covered Parking"]'
);

-- Insert sample parking slots
INSERT INTO parking_slots (zone_id, slot_number, type)
SELECT
  z.id,
  'A-' || n::text,
  CASE WHEN n % 5 = 0 THEN 'premium' ELSE 'standard' END
FROM parking_zones z
CROSS JOIN generate_series(1, 10) n
WHERE z.name = 'Downtown Parking A';

INSERT INTO parking_slots (zone_id, slot_number, type)
SELECT
  z.id,
  'B-' || n::text,
  CASE WHEN n % 5 = 0 THEN 'premium' ELSE 'standard' END
FROM parking_zones z
CROSS JOIN generate_series(1, 15) n
WHERE z.name = 'Central Station Parking';