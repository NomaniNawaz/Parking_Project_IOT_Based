/*
  # Fix permissions for service providers and emergency requests

  1. Changes
    - Add missing permissions for users table
    - Fix RLS policies for service providers and emergency requests
    - Ensure proper cascading permissions

  2. Security
    - Enable RLS on all tables
    - Add proper policies for authenticated users
    - Add admin-specific policies
*/

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO authenticated;

-- Fix service providers policies
DROP POLICY IF EXISTS "Enable admin operations for admins on service_providers" ON service_providers;
DROP POLICY IF EXISTS "Enable read access for all authenticated users on service_providers" ON service_providers;

CREATE POLICY "Enable read access for authenticated users"
  ON service_providers
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable admin operations"
  ON service_providers
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  );

-- Fix emergency requests policies
DROP POLICY IF EXISTS "Enable admin operations for admins on emergency_requests" ON emergency_requests;
DROP POLICY IF EXISTS "Users can view their own emergency requests" ON emergency_requests;
DROP POLICY IF EXISTS "Users can create emergency requests" ON emergency_requests;

CREATE POLICY "View own requests"
  ON emergency_requests
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Create requests"
  ON emergency_requests
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Enable admin operations on requests"
  ON emergency_requests
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  );