/*
  # Fix service providers and emergency requests policies

  1. Changes
    - Grant basic permissions
    - Update service providers policies
    - Update emergency requests policies

  2. Security
    - Enable RLS
    - Use auth.uid() for user identification
    - Ensure proper admin access control
*/

-- Grant basic permissions
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO authenticated;

-- Service providers policies
ALTER TABLE service_providers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable admin operations" ON service_providers;
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON service_providers;
DROP POLICY IF EXISTS "Enable read access for all authenticated users on service_providers" ON service_providers;
DROP POLICY IF EXISTS "Enable admin operations for admins on service_providers" ON service_providers;
DROP POLICY IF EXISTS "Service providers read access" ON service_providers;
DROP POLICY IF EXISTS "Service providers admin access" ON service_providers;

CREATE POLICY "service_providers_read_policy"
    ON service_providers
    FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "service_providers_admin_policy"
    ON service_providers
    FOR ALL
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM profiles p
            WHERE p.id = auth.uid()
            AND p.email = 'admin@parkease.com'
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles p
            WHERE p.id = auth.uid()
            AND p.email = 'admin@parkease.com'
        )
    );

-- Emergency requests policies
ALTER TABLE emergency_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable admin operations on requests" ON emergency_requests;
DROP POLICY IF EXISTS "View own requests" ON emergency_requests;
DROP POLICY IF EXISTS "Create requests" ON emergency_requests;
DROP POLICY IF EXISTS "Users can view their own emergency requests" ON emergency_requests;
DROP POLICY IF EXISTS "Users can create emergency requests" ON emergency_requests;
DROP POLICY IF EXISTS "Enable admin operations for admins on emergency_requests" ON emergency_requests;
DROP POLICY IF EXISTS "Emergency requests view access" ON emergency_requests;
DROP POLICY IF EXISTS "Emergency requests create access" ON emergency_requests;
DROP POLICY IF EXISTS "Emergency requests admin access" ON emergency_requests;

CREATE POLICY "emergency_requests_view_policy"
    ON emergency_requests
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

CREATE POLICY "emergency_requests_create_policy"
    ON emergency_requests
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "emergency_requests_admin_policy"
    ON emergency_requests
    FOR ALL
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM profiles p
            WHERE p.id = auth.uid()
            AND p.email = 'admin@parkease.com'
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles p
            WHERE p.id = auth.uid()
            AND p.email = 'admin@parkease.com'
        )
    );