/*
  # Fix profiles and policies

  1. Changes
    - Grant necessary permissions
    - Update profiles table policies
    - Update service providers policies
    - Update emergency requests policies

  2. Security
    - Maintain RLS
    - Use auth.uid() consistently
    - Ensure proper access control
*/

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO authenticated;

-- Ensure proper permissions for profiles table
ALTER TABLE IF EXISTS profiles ENABLE ROW LEVEL SECURITY;

DO $$ 
BEGIN
    -- Drop existing policies if they exist
    DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
    DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

    -- Create new policies
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'profiles' 
        AND policyname = 'Profiles read access'
    ) THEN
        CREATE POLICY "Profiles read access"
            ON profiles
            FOR SELECT
            TO authenticated
            USING (auth.uid() = id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'profiles' 
        AND policyname = 'Profiles update access'
    ) THEN
        CREATE POLICY "Profiles update access"
            ON profiles
            FOR UPDATE
            TO authenticated
            USING (auth.uid() = id)
            WITH CHECK (auth.uid() = id);
    END IF;
END $$;

-- Update service providers policies
DO $$ 
BEGIN
    DROP POLICY IF EXISTS "Enable admin operations" ON service_providers;
    
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'service_providers' 
        AND policyname = 'Service providers admin operations'
    ) THEN
        CREATE POLICY "Service providers admin operations"
            ON service_providers
            FOR ALL
            TO authenticated
            USING (
                EXISTS (
                    SELECT 1 FROM profiles p
                    WHERE p.id = auth.uid()
                    AND p.email = 'admin@parkease.com'
                )
            )
            WITH CHECK (
                EXISTS (
                    SELECT 1 FROM profiles p
                    WHERE p.id = auth.uid()
                    AND p.email = 'admin@parkease.com'
                )
            );
    END IF;
END $$;

-- Update emergency requests policies
DO $$
BEGIN
    DROP POLICY IF EXISTS "Enable admin operations on requests" ON emergency_requests;
    
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE tablename = 'emergency_requests' 
        AND policyname = 'Emergency requests admin operations'
    ) THEN
        CREATE POLICY "Emergency requests admin operations"
            ON emergency_requests
            FOR ALL
            TO authenticated
            USING (
                EXISTS (
                    SELECT 1 FROM profiles p
                    WHERE p.id = auth.uid()
                    AND p.email = 'admin@parkease.com'
                )
            )
            WITH CHECK (
                EXISTS (
                    SELECT 1 FROM profiles p
                    WHERE p.id = auth.uid()
                    AND p.email = 'admin@parkease.com'
                )
            );
    END IF;
END $$;