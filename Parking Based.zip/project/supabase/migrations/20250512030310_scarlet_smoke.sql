/*
  # Create land registration table

  1. New Tables
    - `parking_registration`
      - `id` (uuid, primary key)
      - `owner_id` (uuid, references profiles)
      - `property_name` (text)
      - `address` (text)
      - `area_size` (numeric)
      - `property_type` (text)
      - `documents` (jsonb)
      - `status` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS parking_registration (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  property_name text NOT NULL,
  address text NOT NULL,
  area_size numeric NOT NULL CHECK (area_size > 0),
  property_type text NOT NULL,
  documents jsonb DEFAULT '{}',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE parking_registration ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own registrations"
  ON parking_registration
  FOR SELECT
  TO authenticated
  USING (auth.uid() = owner_id);

CREATE POLICY "Users can create registrations"
  ON parking_registration
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Admin can view all registrations"
  ON parking_registration
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  );

CREATE POLICY "Admin can manage registrations"
  ON parking_registration
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.email = 'admin@parkease.com'
    )
  );